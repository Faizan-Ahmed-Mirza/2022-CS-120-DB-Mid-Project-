﻿namespace Mid_Project_BD_.GUI
{
    partial class Manage_Rubric
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Update_bt = new Button();
            details_labl = new Label();
            id_txt_bx = new TextBox();
            id_labl = new Label();
            Remove_bt = new Button();
            Add_bt = new Button();
            Details_txt_bx = new RichTextBox();
            clo_id_combo_bx = new ComboBox();
            label1 = new Label();
            rubric_grid = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)rubric_grid).BeginInit();
            SuspendLayout();
            // 
            // Update_bt
            // 
            Update_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Update_bt.Location = new Point(611, 499);
            Update_bt.Name = "Update_bt";
            Update_bt.Size = new Size(280, 79);
            Update_bt.TabIndex = 58;
            Update_bt.Text = "Update Rubric info";
            Update_bt.UseVisualStyleBackColor = true;
            Update_bt.Click += Update_bt_Click;
            // 
            // details_labl
            // 
            details_labl.AutoSize = true;
            details_labl.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            details_labl.Location = new Point(1077, 181);
            details_labl.Name = "details_labl";
            details_labl.Size = new Size(123, 45);
            details_labl.TabIndex = 55;
            details_labl.Text = "Details:";
            // 
            // id_txt_bx
            // 
            id_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            id_txt_bx.Location = new Point(1247, 119);
            id_txt_bx.Name = "id_txt_bx";
            id_txt_bx.Size = new Size(189, 42);
            id_txt_bx.TabIndex = 52;
            // 
            // id_labl
            // 
            id_labl.AutoSize = true;
            id_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            id_labl.Location = new Point(1049, 125);
            id_labl.Name = "id_labl";
            id_labl.Size = new Size(111, 32);
            id_labl.TabIndex = 51;
            id_labl.Text = "Rubric ID";
            // 
            // Remove_bt
            // 
            Remove_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Remove_bt.Location = new Point(1077, 499);
            Remove_bt.Name = "Remove_bt";
            Remove_bt.Size = new Size(278, 79);
            Remove_bt.TabIndex = 50;
            Remove_bt.Text = "Remove";
            Remove_bt.UseVisualStyleBackColor = true;
            Remove_bt.Click += Remove_bt_Click;
            // 
            // Add_bt
            // 
            Add_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Add_bt.Location = new Point(121, 499);
            Add_bt.Name = "Add_bt";
            Add_bt.Size = new Size(280, 79);
            Add_bt.TabIndex = 49;
            Add_bt.Text = "Add  Rubric";
            Add_bt.UseVisualStyleBackColor = true;
            Add_bt.Click += Add_bt_Click;
            // 
            // Details_txt_bx
            // 
            Details_txt_bx.Location = new Point(1049, 238);
            Details_txt_bx.Name = "Details_txt_bx";
            Details_txt_bx.Size = new Size(409, 191);
            Details_txt_bx.TabIndex = 59;
            Details_txt_bx.Text = "";
            // 
            // clo_id_combo_bx
            // 
            clo_id_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            clo_id_combo_bx.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            clo_id_combo_bx.FormattingEnabled = true;
            clo_id_combo_bx.Location = new Point(247, 17);
            clo_id_combo_bx.Name = "clo_id_combo_bx";
            clo_id_combo_bx.Size = new Size(356, 53);
            clo_id_combo_bx.TabIndex = 70;
            clo_id_combo_bx.SelectedIndexChanged += clo_id_combo_bx_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(14, 20);
            label1.Name = "label1";
            label1.Size = new Size(172, 45);
            label1.TabIndex = 69;
            label1.Text = "Select CLO";
            // 
            // rubric_grid
            // 
            rubric_grid.BackgroundColor = SystemColors.Control;
            rubric_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            rubric_grid.Location = new Point(14, 102);
            rubric_grid.MultiSelect = false;
            rubric_grid.Name = "rubric_grid";
            rubric_grid.ReadOnly = true;
            rubric_grid.RowHeadersWidth = 62;
            rubric_grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            rubric_grid.Size = new Size(1010, 359);
            rubric_grid.TabIndex = 68;
            rubric_grid.CellClick += rubric_grid_CellClick;
            // 
            // Manage_Rubric
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            Controls.Add(clo_id_combo_bx);
            Controls.Add(label1);
            Controls.Add(rubric_grid);
            Controls.Add(Details_txt_bx);
            Controls.Add(Update_bt);
            Controls.Add(details_labl);
            Controls.Add(id_txt_bx);
            Controls.Add(id_labl);
            Controls.Add(Remove_bt);
            Controls.Add(Add_bt);
            Name = "Manage_Rubric";
            Size = new Size(1480, 620);
            ((System.ComponentModel.ISupportInitialize)rubric_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button Update_bt;
        private Label details_labl;
        private Label clo_labl;
        private TextBox id_txt_bx;
        private Label id_labl;
        private Button Remove_bt;
        private Button Add_bt;
        private RichTextBox Details_txt_bx;
        private ComboBox clo_id_combo_bx;
        private Label label1;
        private DataGridView rubric_grid;
    }
}
