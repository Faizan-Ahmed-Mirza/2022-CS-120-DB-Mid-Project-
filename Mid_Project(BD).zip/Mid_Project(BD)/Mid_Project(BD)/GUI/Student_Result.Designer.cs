﻿namespace Mid_Project_BD_.GUI
{
    partial class Student_Result
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Student_id_combo_bx = new ComboBox();
            stu_id_labl = new Label();
            rubric_id_combo_bx = new ComboBox();
            label1 = new Label();
            assessment_id_combo_bx = new ComboBox();
            label2 = new Label();
            assess_compo_combo_bx = new ComboBox();
            label3 = new Label();
            rubric_lvl_combo_bx = new ComboBox();
            label4 = new Label();
            date_of_evaluation = new DateTimePicker();
            date_labl = new Label();
            add_result_bt = new Button();
            view_result_bt = new Button();
            generate_clo_report_bt = new Button();
            generate_assess_report = new Button();
            SuspendLayout();
            // 
            // Student_id_combo_bx
            // 
            Student_id_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            Student_id_combo_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Student_id_combo_bx.FormattingEnabled = true;
            Student_id_combo_bx.Location = new Point(465, 120);
            Student_id_combo_bx.Name = "Student_id_combo_bx";
            Student_id_combo_bx.Size = new Size(348, 44);
            Student_id_combo_bx.TabIndex = 83;
            // 
            // stu_id_labl
            // 
            stu_id_labl.AutoSize = true;
            stu_id_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            stu_id_labl.Location = new Point(38, 126);
            stu_id_labl.Name = "stu_id_labl";
            stu_id_labl.Size = new Size(269, 32);
            stu_id_labl.TabIndex = 82;
            stu_id_labl.Text = "Student Registration No";
            // 
            // rubric_id_combo_bx
            // 
            rubric_id_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            rubric_id_combo_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rubric_id_combo_bx.FormattingEnabled = true;
            rubric_id_combo_bx.Location = new Point(465, 195);
            rubric_id_combo_bx.Name = "rubric_id_combo_bx";
            rubric_id_combo_bx.Size = new Size(348, 44);
            rubric_id_combo_bx.TabIndex = 85;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(38, 201);
            label1.Name = "label1";
            label1.Size = new Size(152, 32);
            label1.TabIndex = 84;
            label1.Text = "Select Rubric";
            // 
            // assessment_id_combo_bx
            // 
            assessment_id_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            assessment_id_combo_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            assessment_id_combo_bx.FormattingEnabled = true;
            assessment_id_combo_bx.Location = new Point(465, 338);
            assessment_id_combo_bx.Name = "assessment_id_combo_bx";
            assessment_id_combo_bx.Size = new Size(348, 44);
            assessment_id_combo_bx.TabIndex = 87;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(38, 344);
            label2.Name = "label2";
            label2.Size = new Size(298, 32);
            label2.TabIndex = 86;
            label2.Text = "Select Assessment to mark";
            // 
            // assess_compo_combo_bx
            // 
            assess_compo_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            assess_compo_combo_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            assess_compo_combo_bx.FormattingEnabled = true;
            assess_compo_combo_bx.Location = new Point(465, 413);
            assess_compo_combo_bx.Name = "assess_compo_combo_bx";
            assess_compo_combo_bx.Size = new Size(348, 44);
            assess_compo_combo_bx.TabIndex = 89;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(38, 419);
            label3.Name = "label3";
            label3.Size = new Size(343, 32);
            label3.TabIndex = 88;
            label3.Text = "Select Assessment Component";
            // 
            // rubric_lvl_combo_bx
            // 
            rubric_lvl_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            rubric_lvl_combo_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rubric_lvl_combo_bx.FormattingEnabled = true;
            rubric_lvl_combo_bx.Location = new Point(465, 266);
            rubric_lvl_combo_bx.Name = "rubric_lvl_combo_bx";
            rubric_lvl_combo_bx.Size = new Size(348, 44);
            rubric_lvl_combo_bx.TabIndex = 91;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(38, 272);
            label4.Name = "label4";
            label4.Size = new Size(249, 32);
            label4.TabIndex = 90;
            label4.Text = "Rubric Level Obtained";
            // 
            // date_of_evaluation
            // 
            date_of_evaluation.CalendarFont = new Font("Segoe UI", 22F, FontStyle.Bold, GraphicsUnit.Point, 0);
            date_of_evaluation.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_of_evaluation.Location = new Point(203, 63);
            date_of_evaluation.Name = "date_of_evaluation";
            date_of_evaluation.Size = new Size(351, 37);
            date_of_evaluation.TabIndex = 93;
            // 
            // date_labl
            // 
            date_labl.AutoSize = true;
            date_labl.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_labl.Location = new Point(154, 9);
            date_labl.Name = "date_labl";
            date_labl.Size = new Size(242, 38);
            date_labl.TabIndex = 92;
            date_labl.Text = "Date of Evaluation";
            // 
            // add_result_bt
            // 
            add_result_bt.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            add_result_bt.Location = new Point(38, 533);
            add_result_bt.Name = "add_result_bt";
            add_result_bt.Size = new Size(775, 69);
            add_result_bt.TabIndex = 94;
            add_result_bt.Text = "Add Result";
            add_result_bt.UseVisualStyleBackColor = true;
            add_result_bt.Click += add_result_bt_Click;
            // 
            // view_result_bt
            // 
            view_result_bt.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            view_result_bt.Location = new Point(996, 120);
            view_result_bt.Name = "view_result_bt";
            view_result_bt.Size = new Size(372, 95);
            view_result_bt.TabIndex = 95;
            view_result_bt.Text = "View Existing Results";
            view_result_bt.UseVisualStyleBackColor = true;
            view_result_bt.Click += view_result_bt_Click;
            // 
            // generate_clo_report_bt
            // 
            generate_clo_report_bt.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            generate_clo_report_bt.Location = new Point(996, 249);
            generate_clo_report_bt.Name = "generate_clo_report_bt";
            generate_clo_report_bt.Size = new Size(372, 94);
            generate_clo_report_bt.TabIndex = 96;
            generate_clo_report_bt.Text = "Generate CLO Report";
            generate_clo_report_bt.UseVisualStyleBackColor = true;
            generate_clo_report_bt.Click += generate_clo_report_bt_Click;
            // 
            // generate_assess_report
            // 
            generate_assess_report.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            generate_assess_report.Location = new Point(996, 379);
            generate_assess_report.Name = "generate_assess_report";
            generate_assess_report.Size = new Size(372, 96);
            generate_assess_report.TabIndex = 97;
            generate_assess_report.Text = "Generate Assessment Report";
            generate_assess_report.UseVisualStyleBackColor = true;
            generate_assess_report.Click += generate_assess_report_Click;
            // 
            // Student_Result
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            Controls.Add(generate_assess_report);
            Controls.Add(generate_clo_report_bt);
            Controls.Add(view_result_bt);
            Controls.Add(add_result_bt);
            Controls.Add(date_of_evaluation);
            Controls.Add(date_labl);
            Controls.Add(rubric_lvl_combo_bx);
            Controls.Add(label4);
            Controls.Add(assess_compo_combo_bx);
            Controls.Add(label3);
            Controls.Add(assessment_id_combo_bx);
            Controls.Add(label2);
            Controls.Add(rubric_id_combo_bx);
            Controls.Add(label1);
            Controls.Add(Student_id_combo_bx);
            Controls.Add(stu_id_labl);
            Name = "Student_Result";
            Size = new Size(1480, 620);
            Load += Student_Result_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox Student_id_combo_bx;
        private Label stu_id_labl;
        private ComboBox rubric_id_combo_bx;
        private Label label1;
        private ComboBox assessment_id_combo_bx;
        private Label label2;
        private ComboBox assess_compo_combo_bx;
        private Label label3;
        private Label label4;
        private DateTimePicker date_of_evaluation;
        private Label date_labl;
        private Button add_result_bt;
        private ComboBox rubric_lvl_combo_bx;
        private Button view_result_bt;
        private Button generate_clo_report_bt;
        private Button generate_assess_report;
    }
}
