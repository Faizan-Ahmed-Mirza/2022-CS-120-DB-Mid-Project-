﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Student_Attendance : UserControl
    {
        public Student_Attendance()
        {
            InitializeComponent();
            refresh_atten_rec_box();
            refresh_status_combo_bx();
            refresh_stu_id_combo_bx();
        }

        private void mark_atten_bt_Click(object sender, EventArgs e)
        {
            if (Student_id_combo_bx != null && atten_rec_combo_bx != null && status_combo_bx != null)
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand check_command = new SqlCommand("Select * from StudentAttendance where StudentId = @stu_id and AttendanceId = @atten_rec_id", con);
                check_command.Parameters.AddWithValue("stu_id", int.Parse(Student_id_combo_bx.Text.Substring(0, Student_id_combo_bx.Text.IndexOf('-'))));
                check_command.Parameters.AddWithValue("@atten_rec_id", int.Parse(atten_rec_combo_bx.Text.Substring(0, atten_rec_combo_bx.Text.IndexOf('-'))));
                SqlDataAdapter check_adopter = new SqlDataAdapter(check_command);
                DataTable check_table = new DataTable();
                check_adopter.Fill(check_table);

                if (check_table.Rows.Count != 0)
                {
                    MessageBox.Show("Can't add a new student attendance for a student with already existing record.");
                    return;
                }

                Configuration.refresh_connection();
                SqlCommand cmd = new SqlCommand("Insert into ProjectB.dbo.StudentAttendance (StudentId, AttendanceId, AttendanceStatus)  values(@stu_id, @atten_rec_id, @status_id);", con);
                cmd.Parameters.AddWithValue("@stu_id", int.Parse(Student_id_combo_bx.Text.Substring(0, Student_id_combo_bx.Text.IndexOf('-'))));
                cmd.Parameters.AddWithValue("@atten_rec_id", int.Parse(atten_rec_combo_bx.Text.Substring(0, atten_rec_combo_bx.Text.IndexOf('-'))));
                cmd.Parameters.AddWithValue("@status_id", get_status_id(status_combo_bx.Text));
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                refresh_student_atten_grid();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }

        private void remove_atten_bt_Click(object sender, EventArgs e)
        {
            if (student_atten_grid.SelectedCells == null)
            {
                MessageBox.Show("Please select a component first.");
                return;
            }

            SqlCommand cmd = new SqlCommand("Delete from dbo.StudentAttendance where StudentId = @id", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("@id", student_atten_grid.SelectedRows[0].Cells[2].Value);
            Configuration.refresh_connection();
            cmd.ExecuteNonQuery();
            refresh_student_atten_grid();
        }

        private void refresh_status_combo_bx()
        {
            status_combo_bx.DataSource = new List<string>() { "Present", "Absent", "Leave", "Late" };
        }

        private void refresh_atten_rec_box()
        {
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.ClassAttendance;", Configuration.getInstance().getConnection());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DataColumn display_column = new DataColumn("DisplayColumn", typeof(string));
            dt.Columns.Add(display_column);

            foreach (DataRow row in dt.Rows)
            {
                DateOnly dateOnly = DateOnly.FromDateTime((DateTime)row[1]);
                string concatenatedValue = $"{row[0]}--- {dateOnly}";
                row["DisplayColumn"] = concatenatedValue;
            }

            atten_rec_combo_bx.DisplayMember = "DisplayColumn";
            atten_rec_combo_bx.DataSource = dt;
            atten_rec_combo_bx.Refresh();
        }


        private void refresh_stu_id_combo_bx()
        {
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.Student;", Configuration.getInstance().getConnection());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DataColumn display_column = new DataColumn("DisplayColumn", typeof(string));
            dt.Columns.Add(display_column);

            foreach (DataRow row in dt.Rows)
            {
                string concatenatedValue = $"{row[0]}--- {row[1]}";
                row["DisplayColumn"] = concatenatedValue;
            }

            Student_id_combo_bx.DisplayMember = "DisplayColumn";
            Student_id_combo_bx.DataSource = dt;
            Student_id_combo_bx.Refresh();
        }


        private void refresh_student_atten_grid()
        {
            if (atten_rec_combo_bx.Text != null)
            {
                Configuration.refresh_connection();
                SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.StudentAttendance where StudentAttendance.AttendanceId = @atten_rec_id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@atten_rec_id", int.Parse(atten_rec_combo_bx.Text.Substring(0, atten_rec_combo_bx.Text.IndexOf('-'))));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                DataColumn name_column = new DataColumn("Student Name", typeof(string));
                DataColumn status_column = new DataColumn("Status", typeof(string));
                dt.Columns.Add(name_column);
                Configuration.refresh_connection();
                string name = "";
                dt.Columns[0].ColumnName = "Attendance ID";
                dt.Columns[1].ColumnName = "Student ID";
                dt.Columns[2].ColumnName = "Status_old";
                dt.Columns[3].ColumnName = "Student Name";
                dt.Columns.Add(status_column);



                foreach (DataRow sample_row in dt.Rows)
                {
                    Configuration.refresh_connection();
                    SqlCommand cmd1 = new SqlCommand("Select FirstName from ProjectB.dbo.Student where Student.Id = @stu_id;", Configuration.getInstance().getConnection());
                    cmd1.Parameters.AddWithValue("@stu_id", int.Parse(sample_row[1].ToString()));
                    object result = cmd1.ExecuteScalar();
                    if (result != null)
                    {
                        name = result.ToString();
                    }
                    sample_row["Student Name"] = name;
                    sample_row["Status"] = get_status_string(int.Parse(sample_row[2].ToString()));
                }
                dt.Columns["Student Name"].SetOrdinal(1);
                dt.Columns.RemoveAt(3);
                student_atten_grid.DataSource = dt;
                student_atten_grid.Refresh();
            }
        }

        private void date_created_ValueChanged(object sender, EventArgs e)
        {
            add_new_atten_rec_bt.Enabled = true;
        }

        private void atten_rec_combo_bx_SelectedIndexChanged(object sender, EventArgs e)
        {
            refresh_student_atten_grid();
        }


        private int get_status_id(string status_in_string)
        {
            if (status_in_string == "Present")
            {
                return 1;
            }
            else if (status_in_string == "Absent")
            {
                return 2;
            }
            else if (status_in_string == "Leave")
            {
                return 3;
            }
            else
            {
                return 4;
            }
        }


        private string get_status_string(int sample_value)
        {
            if (sample_value == 1)
            {
                return "Present";
            }
            else if (sample_value == 2)
            {
                return "Absent";
            }
            else if (sample_value == 3)
            {
                return "Leave";
            }
            else
            {
                return "Late";
            }
        }

        private void student_atten_grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void add_new_atten_rec_bt_Click(object sender, EventArgs e)
        {
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.ClassAttendance where AttendanceDate = @date;", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("@date", date_created.Value.Date.ToString("yyyy-MM-dd"));
            SqlDataAdapter check_adopter = new SqlDataAdapter(cmd);
            DataTable check_table = new DataTable();
            check_adopter.Fill(check_table);

            if (check_table.Rows.Count > 0)
            {
                MessageBox.Show("Can't add a new record while there's still already existing record with same date.");
                return;
            }

            Configuration.refresh_connection();
            SqlCommand cmd1 = new SqlCommand("Insert into ProjectB.dbo.ClassAttendance (AttendanceDate) values(@atten_date);", Configuration.getInstance().getConnection());
            cmd1.Parameters.AddWithValue("@atten_date", date_created.Value.ToString("yyyy-MM-dd"));
            cmd1.ExecuteNonQuery();
            MessageBox.Show("Attendance Record added successfully, please select record from the selection box to add attendances aganist it.");
            refresh_atten_rec_box();

        }

        private void del_atten_rec_bt_Click(object sender, EventArgs e)
        {
            SqlCommand delete_cmd = new SqlCommand("Delete from ProjectB.dbo.StudentAttendance where AttendanceId = @id;", Configuration.getInstance().getConnection());
            delete_cmd.Parameters.AddWithValue("@id", atten_rec_combo_bx.Text.Substring(0,atten_rec_combo_bx.Text.IndexOf('-')));
            Configuration.refresh_connection();
            delete_cmd.ExecuteNonQuery();


            string date = atten_rec_combo_bx.Text.Substring(5);
            DateOnly date_created = DateOnly.ParseExact(date, "dd/MM/yyyy", null);
            SqlCommand cmd = new SqlCommand("Delete from ProjectB.dbo.ClassAttendance where AttendanceDate = @date;", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("date", date_created.ToString("yyyy-MM-dd"));
            Configuration.refresh_connection();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Attendance record deleted successfully.");
            refresh_atten_rec_box();
            refresh_student_atten_grid();
        }
    }
}
