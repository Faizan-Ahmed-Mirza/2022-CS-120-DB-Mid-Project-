﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Pop_Up_Form : Form
    {
        private UserControl user_form_to_show;
        public Pop_Up_Form(UserControl sample_form)
        {
            InitializeComponent();
            user_form_to_show = sample_form;
            set_current_section(user_form_to_show);
        }


        private void set_current_section(UserControl section_to_set)
        {
            panel1.Controls.Remove(user_form_to_show);
            user_form_to_show = section_to_set;
            panel1.Controls.Add(user_form_to_show);
        }
    }
}
