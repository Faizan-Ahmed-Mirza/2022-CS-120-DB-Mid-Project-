﻿namespace Mid_Project_BD_.GUI
{
    partial class Manage_CLO
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            date_created = new DateTimePicker();
            Update_bt = new Button();
            date_labl = new Label();
            name_txt_bx = new TextBox();
            name_labl = new Label();
            Remove_bt = new Button();
            Add_bt = new Button();
            clo_grid = new DataGridView();
            date_updated = new DateTimePicker();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)clo_grid).BeginInit();
            SuspendLayout();
            // 
            // date_created
            // 
            date_created.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_created.Location = new Point(1080, 347);
            date_created.Name = "date_created";
            date_created.Size = new Size(351, 37);
            date_created.TabIndex = 59;
            // 
            // Update_bt
            // 
            Update_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Update_bt.Location = new Point(611, 499);
            Update_bt.Name = "Update_bt";
            Update_bt.Size = new Size(280, 79);
            Update_bt.TabIndex = 58;
            Update_bt.Text = "Update CLO info";
            Update_bt.UseVisualStyleBackColor = true;
            Update_bt.Click += Update_bt_Click;
            // 
            // date_labl
            // 
            date_labl.AutoSize = true;
            date_labl.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_labl.Location = new Point(1147, 293);
            date_labl.Name = "date_labl";
            date_labl.Size = new Size(220, 38);
            date_labl.TabIndex = 57;
            date_labl.Text = "Date of Creation";
            // 
            // name_txt_bx
            // 
            name_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            name_txt_bx.Location = new Point(1267, 123);
            name_txt_bx.Name = "name_txt_bx";
            name_txt_bx.Size = new Size(189, 42);
            name_txt_bx.TabIndex = 52;
            // 
            // name_labl
            // 
            name_labl.AutoSize = true;
            name_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            name_labl.Location = new Point(1047, 129);
            name_labl.Name = "name_labl";
            name_labl.Size = new Size(78, 32);
            name_labl.TabIndex = 51;
            name_labl.Text = "Name";
            // 
            // Remove_bt
            // 
            Remove_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Remove_bt.Location = new Point(1077, 499);
            Remove_bt.Name = "Remove_bt";
            Remove_bt.Size = new Size(278, 79);
            Remove_bt.TabIndex = 50;
            Remove_bt.Text = "Remove";
            Remove_bt.UseVisualStyleBackColor = true;
            Remove_bt.Click += Remove_bt_Click;
            // 
            // Add_bt
            // 
            Add_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Add_bt.Location = new Point(121, 499);
            Add_bt.Name = "Add_bt";
            Add_bt.Size = new Size(280, 79);
            Add_bt.TabIndex = 49;
            Add_bt.Text = "Add CLO";
            Add_bt.UseVisualStyleBackColor = true;
            Add_bt.Click += Add_bt_Click;
            // 
            // clo_grid
            // 
            clo_grid.BackgroundColor = SystemColors.Control;
            clo_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            clo_grid.Location = new Point(24, 43);
            clo_grid.MultiSelect = false;
            clo_grid.Name = "clo_grid";
            clo_grid.ReadOnly = true;
            clo_grid.RowHeadersWidth = 62;
            clo_grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            clo_grid.Size = new Size(1003, 410);
            clo_grid.TabIndex = 48;
            clo_grid.CellClick += clo_grid_CellClick;
            // 
            // date_updated
            // 
            date_updated.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_updated.Location = new Point(1267, 202);
            date_updated.Name = "date_updated";
            date_updated.Size = new Size(189, 39);
            date_updated.TabIndex = 67;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(1047, 207);
            label3.Name = "label3";
            label3.Size = new Size(162, 32);
            label3.TabIndex = 66;
            label3.Text = "Date Updated";
            // 
            // Manage_CLO
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            Controls.Add(date_updated);
            Controls.Add(label3);
            Controls.Add(date_created);
            Controls.Add(Update_bt);
            Controls.Add(date_labl);
            Controls.Add(name_txt_bx);
            Controls.Add(name_labl);
            Controls.Add(Remove_bt);
            Controls.Add(Add_bt);
            Controls.Add(clo_grid);
            Name = "Manage_CLO";
            Size = new Size(1480, 620);
            ((System.ComponentModel.ISupportInitialize)clo_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker date_created;
        private Button Update_bt;
        private Label date_labl;
        private TextBox name_txt_bx;
        private Label name_labl;
        private Button Remove_bt;
        private Button Add_bt;
        private DataGridView clo_grid;
        private DateTimePicker date_updated;
        private Label label3;
    }
}
