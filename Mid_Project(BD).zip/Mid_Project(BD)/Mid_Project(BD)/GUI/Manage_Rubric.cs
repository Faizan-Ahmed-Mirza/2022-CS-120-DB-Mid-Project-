﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Manage_Rubric : UserControl
    {
        public Manage_Rubric()
        {
            InitializeComponent();
            refresh_clo_combo_bx_options();
            refresh_rubric_grid();
        }

        private void Add_bt_Click(object sender, EventArgs e)
        {
            if (id_txt_bx != null && clo_id_combo_bx != null && Details_txt_bx != null)
            {
                if (!int.TryParse(id_txt_bx.Text, out _))
                {
                    MessageBox.Show("ID must be a numeric value.");
                    return;
                }




                var con = Configuration.getInstance().getConnection();
                SqlCommand check_command = new SqlCommand("Select * from ProjectB.dbo.Rubric where Rubric.Id = @id;", con);
                check_command.Parameters.AddWithValue("@id", int.Parse(id_txt_bx.Text));
                SqlDataAdapter check_adopter = new SqlDataAdapter(check_command);
                DataTable check_table = new DataTable();
                check_adopter.Fill(check_table);

                if (check_table.Rows.Count != 0)
                {
                    MessageBox.Show("Can't add a new Rubric with an ID already existing .");
                    return;
                }




                SqlCommand cmd = new SqlCommand("Insert into ProjectB.dbo.Rubric values(@id, @details, @clo_id);", con);
                cmd.Parameters.AddWithValue("@id", int.Parse(id_txt_bx.Text));
                cmd.Parameters.AddWithValue("@details", Details_txt_bx.Text);
                cmd.Parameters.AddWithValue("@clo_id", int.Parse(clo_id_combo_bx.Text.Substring(0, clo_id_combo_bx.Text.IndexOf('-'))));
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                refresh_rubric_grid();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }

        private void Update_bt_Click(object sender, EventArgs e)
        {
            if (id_txt_bx != null && clo_id_combo_bx != null && Details_txt_bx != null)
            {
                if (!int.TryParse(id_txt_bx.Text, out _))
                {
                    MessageBox.Show("ID must be a numeric value.");
                }

                SqlCommand cmd = new SqlCommand("Update ProjectB.dbo.Rubric set Id = @id, Details = @details, CloId = @clo_id where Id = @prev_id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@id", int.Parse(id_txt_bx.Text));
                cmd.Parameters.AddWithValue("@details", Details_txt_bx.Text);
                cmd.Parameters.AddWithValue("@clo_id", int.Parse(clo_id_combo_bx.Text.Substring(0, clo_id_combo_bx.Text.IndexOf('-'))));
                cmd.Parameters.AddWithValue("@prev_id", rubric_grid.SelectedRows[0].Cells[0].Value);
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Rubric info updated successfully!");
                refresh_rubric_grid();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }

        private void Remove_bt_Click(object sender, EventArgs e)
        {
            if (rubric_grid.SelectedCells == null)
            {
                MessageBox.Show("Please select a component first.");
                return;
            }

            SqlCommand cmd = new SqlCommand("Delete from dbo.Rubric where Id = @id", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("@id", rubric_grid.SelectedRows[0].Cells["Id"].Value);
            SqlCommand cmd1 = new SqlCommand("Delete from RubricLevel where RubricId = @rubric_id;", Configuration.getInstance().getConnection());
            cmd1.Parameters.AddWithValue("@rubric_id", rubric_grid.SelectedRows[0].Cells["Id"].Value);
            Configuration.refresh_connection();
            cmd1.ExecuteNonQuery();
            Configuration.refresh_connection();
            cmd.ExecuteNonQuery();
            refresh_rubric_grid();
        }

        private void rubric_grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (rubric_grid.SelectedRows.Count > 0)
            {
                DataGridViewRow selected_row = rubric_grid.SelectedRows[0];
                id_txt_bx.Text = selected_row.Cells[0].Value.ToString();
                Details_txt_bx.Text = selected_row.Cells[1].Value.ToString();
                clo_id_combo_bx.SelectedText = selected_row.Cells[2].Value.ToString();
            }
        }

        private void clo_id_combo_bx_SelectedIndexChanged(object sender, EventArgs e)
        {
            refresh_rubric_grid();
        }

        private void refresh_clo_combo_bx_options()
        {
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.Clo;", Configuration.getInstance().getConnection());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DataColumn display_column = new DataColumn("DisplayColumn", typeof(string));
            dt.Columns.Add(display_column);

            foreach (DataRow row in dt.Rows)
            {
                string concatenatedValue = $"{row[0]}--- {row[1]}";
                row["DisplayColumn"] = concatenatedValue;
            }

            clo_id_combo_bx.DisplayMember = "DisplayColumn";
            clo_id_combo_bx.DataSource = dt;
            clo_id_combo_bx.Refresh();
        }

        private void refresh_rubric_grid()
        {
            if (clo_id_combo_bx.Text != null)
            {
                Configuration.refresh_connection();
                SqlCommand cmd = new SqlCommand("Select* from ProjectB.dbo.Rubric where CloId = @clo_id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@clo_id", int.Parse(clo_id_combo_bx.Text.Substring(0, clo_id_combo_bx.Text.IndexOf('-'))));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dt.Columns[2].ColumnName = "CLO Id";
                rubric_grid.DataSource = dt;
                rubric_grid.Refresh();
            }
        }



    }
}
