﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Manage_assessment_components : UserControl
    {
        public Manage_assessment_components()
        {
            InitializeComponent();
            refresh_data();
        }


        private void Add_bt_Click(object sender, EventArgs e)
        {
            if (name_txt_bx != null && date_updated != null && marks_txt_bx != null && date_created != null && rubric_id_combo_bx != null && assessment_combo_bx != null)
            {
                if (!int.TryParse(marks_txt_bx.Text, out _))
                {
                    MessageBox.Show("Marks, RubricId and AssessmentId must be a numeric value.");
                    return;
                }

                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("Insert into dbo.AssessmentComponent values (@name, @rubric_id, @total_marks, @date_created, @date_updated, @assessment_id);", con);
                cmd.Parameters.AddWithValue("@name", name_txt_bx.Text);
                cmd.Parameters.AddWithValue("@date_created", date_created.Value.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@total_marks", marks_txt_bx.Text);
                cmd.Parameters.AddWithValue("@date_updated", date_updated.Value.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@rubric_id", rubric_id_combo_bx.Text);
                cmd.Parameters.AddWithValue("@assessment_id", assessment_combo_bx.Text.Substring(0, assessment_combo_bx.Text.IndexOf('-')));
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                refresh_ass_compo_grid_data();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }


        private void Update_bt_Click(object sender, EventArgs e)
        {
            if (name_txt_bx != null && date_updated != null && marks_txt_bx != null && date_created != null && rubric_id_combo_bx != null && assessment_combo_bx != null)
            {
                if (!int.TryParse(marks_txt_bx.Text, out _))
                {
                    MessageBox.Show("Marks, RubricId and AssessmentId must be a numeric value.");
                }

                SqlCommand cmd = new SqlCommand("Update ProjectB.dbo.AssessmentComponent set Name = @name, DateCreated = @date_created, TotalMarks = @total_marks, DateUpdated = @date_updated, RubricId = @rubric_id , AssessmentId = @assessment_id where Id = @id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@name", name_txt_bx.Text);
                cmd.Parameters.AddWithValue("@date_created", date_created.Value.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@total_marks", marks_txt_bx.Text);
                cmd.Parameters.AddWithValue("@date_updated", date_updated.Value.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@rubric_id", rubric_id_combo_bx.Text);
                cmd.Parameters.AddWithValue("@assessment_id", assessment_combo_bx.Text.Substring(0, assessment_combo_bx.Text.IndexOf('-')));
                cmd.Parameters.AddWithValue("@id", ass_compo_grid.SelectedRows[0].Cells[0].Value);
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Assessment Component info updated successfully!");
                refresh_ass_compo_grid_data();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }


        private void Remove_bt_Click(object sender, EventArgs e)
        {
            if (ass_compo_grid.SelectedCells == null)
            {
                MessageBox.Show("Please select a component first.");
                return;
            }

            SqlCommand cmd = new SqlCommand("Delete from dbo.AssessmentComponent where Id = @id", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("@id", ass_compo_grid.SelectedRows[0].Cells["Id"].Value);
            Configuration.refresh_connection();
            cmd.ExecuteNonQuery();
            refresh_ass_compo_grid_data();
        }


        private void ass_compo_grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (ass_compo_grid.SelectedRows.Count > 0)
            {
                DataGridViewRow selected_row = ass_compo_grid.SelectedRows[0];
                name_txt_bx.Text = selected_row.Cells[1].Value.ToString();
                rubric_id_combo_bx.SelectedText = selected_row.Cells[2].Value.ToString();
                marks_txt_bx.Text = selected_row.Cells[3].Value.ToString();
                date_created.Text = selected_row.Cells[4].Value.ToString();
                date_updated.Text = selected_row.Cells[5].Value.ToString();
            }
        }


        private void assessment_combo_bx_SelectedIndexChanged(object sender, EventArgs e)
        {
            refresh_ass_compo_grid_data();
        }


        private void refresh_ass_compo_grid_data()
        {
            if (assessment_combo_bx.Text != null)
            {
                Configuration.refresh_connection();
                SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.AssessmentComponent where AssessmentId = @assessment_id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@assessment_id", int.Parse(assessment_combo_bx.Text.Substring(0, assessment_combo_bx.Text.IndexOf('-'))));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                ass_compo_grid.DataSource = dt;
                ass_compo_grid.Refresh();
            }
        }


        private void refresh_assessment_data_for_combo_box()
        {
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.Assessment;", Configuration.getInstance().getConnection());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DataColumn display_column = new DataColumn("DisplayColumn", typeof(string));
            dt.Columns.Add(display_column);

            foreach (DataRow row in dt.Rows)
            {
                string concatenatedValue = $"{row[0]}--- {row[1]}";
                row["DisplayColumn"] = concatenatedValue;
            }

            assessment_combo_bx.DisplayMember = "DisplayColumn";
            assessment_combo_bx.DataSource = dt;
            assessment_combo_bx.Refresh();
        }


        private void refresh_rubric_combo_bx()
        {
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.Rubric;", Configuration.getInstance().getConnection());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            rubric_id_combo_bx.DisplayMember = "Id";
            rubric_id_combo_bx.DataSource = dt;
        }


        private void refresh_data()
        {
            refresh_assessment_data_for_combo_box();
            refresh_ass_compo_grid_data();
            refresh_rubric_combo_bx();
        }

    }
}
