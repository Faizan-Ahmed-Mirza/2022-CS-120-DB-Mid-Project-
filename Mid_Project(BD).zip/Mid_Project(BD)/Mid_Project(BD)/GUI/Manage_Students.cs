﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Manage_Students : UserControl
    {
        public Manage_Students()
        {
            InitializeComponent();
            refresh_stu_info_data();
            status_combo_bx.DataSource = new List<string>() { "Active", "Inactive"};

        }

        private void Add_bt_Click(object sender, EventArgs e)
        {
            if (First_name_txt_bx != null && email_txt_bx != null && status_combo_bx != null && reg_no_txt_bx != null)
            {

                var con = Configuration.getInstance().getConnection();
                SqlCommand check_command = new SqlCommand("Select * from ProjectB.dbo.Student where Student.RegistrationNumber = @reg_no;", con);
                check_command.Parameters.AddWithValue("@reg_no", reg_no_txt_bx.Text);
                SqlDataAdapter check_adopter = new SqlDataAdapter(check_command);
                DataTable check_table = new DataTable();
                check_adopter.Fill(check_table);

                if (check_table.Rows.Count != 0)
                {
                    MessageBox.Show("Can't add a new student for a registration number already existing .");
                    return;
                }



                SqlCommand cmd = new SqlCommand("Insert into dbo.Student values (@First_Name, @Last_Name, @Contact, @Email, @Registration_no,  @Status)", con);
                cmd.Parameters.AddWithValue("@First_Name", First_name_txt_bx.Text);
                cmd.Parameters.AddWithValue("@Last_Name", Last_name_txt_bx.Text);
                cmd.Parameters.AddWithValue("@Contact", Contact_txt_bx.Text);
                cmd.Parameters.AddWithValue("@Email", email_txt_bx.Text);
                cmd.Parameters.AddWithValue("@Registration_no", reg_no_txt_bx.Text);
                cmd.Parameters.AddWithValue("@Status", get_status_index(status_combo_bx.Text));
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                refresh_stu_info_data();
            }

            else
            {
                MessageBox.Show("Null Values are allowed only for Last_Name and Contact...");
            }
        }


        private void Update_bt_Click(object sender, EventArgs e)
        {
            if(First_name_txt_bx != null && email_txt_bx != null && status_combo_bx != null && reg_no_txt_bx != null)
            {
                SqlCommand cmd = new SqlCommand("Update ProjectB.dbo.Student set FirstName = @firstname, LastName = @lastname, Contact = @contact , Email = @email,RegistrationNumber = @reg_no, Status = @status where Id = @stu_id; ", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@firstname", First_name_txt_bx.Text);
                cmd.Parameters.AddWithValue("@lastname", Last_name_txt_bx.Text);
                cmd.Parameters.AddWithValue("@contact", Contact_txt_bx.Text);
                cmd.Parameters.AddWithValue("@email", email_txt_bx.Text);
                cmd.Parameters.AddWithValue("@reg_no", reg_no_txt_bx.Text);
                cmd.Parameters.AddWithValue("@status", get_status_index(status_combo_bx.Text));
                cmd.Parameters.AddWithValue("@stu_id", Students_info.SelectedRows[0].Cells[0].Value);
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Student info updated successfully!");
                refresh_stu_info_data();
            }

            else
            {
                MessageBox.Show("Null Values are allowed only for Last_Name and Contact...");
            }

        }


        private void Remove_bt_Click(object sender, EventArgs e)
        {
            if (Students_info.SelectedCells == null)
            {
                MessageBox.Show("Please select a student first.");
                return;
            }

            Configuration.refresh_connection();
            SqlCommand cmd1 = new SqlCommand("Delete from ProjectB.dbo.StudentAttendance where StudentId = @id;", Configuration.getInstance().getConnection());
            cmd1.Parameters.AddWithValue("@id", Students_info.SelectedRows[0].Cells["Id"].Value);
            cmd1.ExecuteNonQuery();

            SqlCommand cmd = new SqlCommand("Delete from dbo.Student where Student.Id = @stu_id_to_del", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("@stu_id_to_del", Students_info.SelectedRows[0].Cells["Id"].Value);
            Configuration.refresh_connection();
            cmd.ExecuteNonQuery();
            refresh_stu_info_data();

        }

        private void Students_info_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Students_info.SelectedRows.Count > 0)
            {
                DataGridViewRow selected_row = Students_info.SelectedRows[0];
                First_name_txt_bx.Text = selected_row.Cells[1].Value.ToString();
                Last_name_txt_bx.Text = selected_row.Cells[2].Value.ToString();
                Contact_txt_bx.Text = selected_row.Cells[3].Value.ToString();
                email_txt_bx.Text = selected_row.Cells[4].Value.ToString();
                reg_no_txt_bx.Text = selected_row.Cells[5].Value.ToString();
                status_combo_bx.Text = selected_row.Cells[6].Value.ToString();
            }
        }


        private void refresh_stu_info_data()
        {
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select * from dbo.Student;", Configuration.getInstance().getConnection());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DataColumn status_column =  new DataColumn("-Status-",typeof(string));
            dt.Columns.Add(status_column);
            foreach (DataRow sample_row in dt.Rows)
            {
                sample_row["-Status-"] = get_status_string(int.Parse(sample_row["Status"].ToString()));
            }
            dt.Columns.Remove("Status");
            Students_info.DataSource = dt;
            Students_info.Refresh();
        }

        
        private int get_status_index(string status)
        {
            if(status == "Active")
            {
                return 5;
            }
            else
            {
                return 6;
            }
        }



        private string get_status_string(int index)
        {
            if(index == 5)
            {
                return "Active";
            }
            else
            {
                return "InActive";
            }
        }


    }
}
