﻿namespace Mid_Project_BD_.GUI
{
    partial class Manage_Students
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Students_info = new DataGridView();
            Add_bt = new Button();
            Remove_bt = new Button();
            reg_no_txt_bx = new TextBox();
            reg_labl = new Label();
            Email_labl = new Label();
            email_txt_bx = new TextBox();
            Contact_txt_bx = new TextBox();
            contact = new Label();
            status_labl = new Label();
            Last_name_txt_bx = new TextBox();
            last_name_labl = new Label();
            first_name_labl = new Label();
            First_name_txt_bx = new TextBox();
            Update_bt = new Button();
            status_combo_bx = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)Students_info).BeginInit();
            SuspendLayout();
            // 
            // Students_info
            // 
            Students_info.BackgroundColor = SystemColors.Control;
            Students_info.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Students_info.Location = new Point(14, 16);
            Students_info.MultiSelect = false;
            Students_info.Name = "Students_info";
            Students_info.ReadOnly = true;
            Students_info.RowHeadersWidth = 62;
            Students_info.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Students_info.Size = new Size(1003, 410);
            Students_info.TabIndex = 0;
            Students_info.CellClick += Students_info_CellClick;
            // 
            // Add_bt
            // 
            Add_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Add_bt.Location = new Point(111, 472);
            Add_bt.Name = "Add_bt";
            Add_bt.Size = new Size(280, 79);
            Add_bt.TabIndex = 1;
            Add_bt.Text = "Add \r\nStudent info";
            Add_bt.UseVisualStyleBackColor = true;
            Add_bt.Click += Add_bt_Click;
            // 
            // Remove_bt
            // 
            Remove_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Remove_bt.Location = new Point(1067, 472);
            Remove_bt.Name = "Remove_bt";
            Remove_bt.Size = new Size(278, 79);
            Remove_bt.TabIndex = 3;
            Remove_bt.Text = "Remove";
            Remove_bt.UseVisualStyleBackColor = true;
            Remove_bt.Click += Remove_bt_Click;
            // 
            // reg_no_txt_bx
            // 
            reg_no_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            reg_no_txt_bx.Location = new Point(1257, 356);
            reg_no_txt_bx.Name = "reg_no_txt_bx";
            reg_no_txt_bx.Size = new Size(189, 42);
            reg_no_txt_bx.TabIndex = 29;
            // 
            // reg_labl
            // 
            reg_labl.AutoSize = true;
            reg_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            reg_labl.Location = new Point(1037, 362);
            reg_labl.Name = "reg_labl";
            reg_labl.Size = new Size(175, 32);
            reg_labl.TabIndex = 28;
            reg_labl.Text = "Registration no";
            // 
            // Email_labl
            // 
            Email_labl.AutoSize = true;
            Email_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Email_labl.Location = new Point(1037, 296);
            Email_labl.Name = "Email_labl";
            Email_labl.Size = new Size(71, 32);
            Email_labl.TabIndex = 27;
            Email_labl.Text = "Email";
            // 
            // email_txt_bx
            // 
            email_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            email_txt_bx.Location = new Point(1257, 290);
            email_txt_bx.Name = "email_txt_bx";
            email_txt_bx.Size = new Size(189, 42);
            email_txt_bx.TabIndex = 26;
            // 
            // Contact_txt_bx
            // 
            Contact_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Contact_txt_bx.Location = new Point(1257, 224);
            Contact_txt_bx.Name = "Contact_txt_bx";
            Contact_txt_bx.Size = new Size(189, 42);
            Contact_txt_bx.TabIndex = 25;
            // 
            // contact
            // 
            contact.AutoSize = true;
            contact.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            contact.Location = new Point(1037, 230);
            contact.Name = "contact";
            contact.Size = new Size(96, 32);
            contact.TabIndex = 24;
            contact.Text = "Contact";
            // 
            // status_labl
            // 
            status_labl.AutoSize = true;
            status_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            status_labl.Location = new Point(1037, 164);
            status_labl.Name = "status_labl";
            status_labl.Size = new Size(78, 32);
            status_labl.TabIndex = 23;
            status_labl.Text = "Status";
            // 
            // Last_name_txt_bx
            // 
            Last_name_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Last_name_txt_bx.Location = new Point(1257, 96);
            Last_name_txt_bx.Name = "Last_name_txt_bx";
            Last_name_txt_bx.Size = new Size(189, 42);
            Last_name_txt_bx.TabIndex = 21;
            // 
            // last_name_labl
            // 
            last_name_labl.AutoSize = true;
            last_name_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            last_name_labl.Location = new Point(1037, 102);
            last_name_labl.Name = "last_name_labl";
            last_name_labl.Size = new Size(126, 32);
            last_name_labl.TabIndex = 20;
            last_name_labl.Text = "Last Name";
            // 
            // first_name_labl
            // 
            first_name_labl.AutoSize = true;
            first_name_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            first_name_labl.Location = new Point(1037, 36);
            first_name_labl.Name = "first_name_labl";
            first_name_labl.Size = new Size(129, 32);
            first_name_labl.TabIndex = 19;
            first_name_labl.Text = "First Name";
            // 
            // First_name_txt_bx
            // 
            First_name_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            First_name_txt_bx.Location = new Point(1257, 30);
            First_name_txt_bx.Name = "First_name_txt_bx";
            First_name_txt_bx.Size = new Size(189, 42);
            First_name_txt_bx.TabIndex = 18;
            // 
            // Update_bt
            // 
            Update_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Update_bt.Location = new Point(601, 472);
            Update_bt.Name = "Update_bt";
            Update_bt.Size = new Size(280, 79);
            Update_bt.TabIndex = 30;
            Update_bt.Text = "Update \r\nStudent info";
            Update_bt.UseVisualStyleBackColor = true;
            Update_bt.Click += Update_bt_Click;
            // 
            // status_combo_bx
            // 
            status_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            status_combo_bx.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            status_combo_bx.FormattingEnabled = true;
            status_combo_bx.Location = new Point(1257, 161);
            status_combo_bx.Name = "status_combo_bx";
            status_combo_bx.Size = new Size(189, 40);
            status_combo_bx.TabIndex = 31;
            // 
            // Manage_Students
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            Controls.Add(status_combo_bx);
            Controls.Add(Update_bt);
            Controls.Add(reg_no_txt_bx);
            Controls.Add(reg_labl);
            Controls.Add(Email_labl);
            Controls.Add(email_txt_bx);
            Controls.Add(Contact_txt_bx);
            Controls.Add(contact);
            Controls.Add(status_labl);
            Controls.Add(Last_name_txt_bx);
            Controls.Add(last_name_labl);
            Controls.Add(first_name_labl);
            Controls.Add(First_name_txt_bx);
            Controls.Add(Remove_bt);
            Controls.Add(Add_bt);
            Controls.Add(Students_info);
            Name = "Manage_Students";
            Size = new Size(1480, 620);
            ((System.ComponentModel.ISupportInitialize)Students_info).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView Students_info;
        private Button Add_bt;
        private Button Remove_bt;
        private TextBox reg_no_txt_bx;
        private Label reg_labl;
        private Label Email_labl;
        private TextBox email_txt_bx;
        private TextBox Contact_txt_bx;
        private Label contact;
        private Label status_labl;
        private TextBox Last_name_txt_bx;
        private Label last_name_labl;
        private Label first_name_labl;
        private TextBox First_name_txt_bx;
        private Button Update_bt;
        private ComboBox status_combo_bx;
    }
}
