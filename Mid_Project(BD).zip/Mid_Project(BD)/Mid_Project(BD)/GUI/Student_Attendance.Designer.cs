﻿namespace Mid_Project_BD_.GUI
{
    partial class Student_Attendance
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            date_created = new DateTimePicker();
            date_labl = new Label();
            stu_id_labl = new Label();
            mark_atten_bt = new Button();
            student_atten_grid = new DataGridView();
            status_combo_bx = new ComboBox();
            label2 = new Label();
            Student_id_combo_bx = new ComboBox();
            atten_rec_combo_bx = new ComboBox();
            label1 = new Label();
            add_new_atten_rec_bt = new Button();
            del_atten_rec_bt = new Button();
            remove_atten_bt = new Button();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)student_atten_grid).BeginInit();
            SuspendLayout();
            // 
            // date_created
            // 
            date_created.CalendarFont = new Font("Segoe UI Semibold", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            date_created.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_created.Location = new Point(1062, 383);
            date_created.Name = "date_created";
            date_created.Size = new Size(349, 37);
            date_created.TabIndex = 75;
            date_created.ValueChanged += date_created_ValueChanged;
            // 
            // date_labl
            // 
            date_labl.AutoSize = true;
            date_labl.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_labl.Location = new Point(1022, 330);
            date_labl.Name = "date_labl";
            date_labl.Size = new Size(224, 38);
            date_labl.TabIndex = 73;
            date_labl.Text = "Attendance Date";
            // 
            // stu_id_labl
            // 
            stu_id_labl.AutoSize = true;
            stu_id_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            stu_id_labl.Location = new Point(1022, 101);
            stu_id_labl.Name = "stu_id_labl";
            stu_id_labl.Size = new Size(127, 32);
            stu_id_labl.TabIndex = 71;
            stu_id_labl.Text = "Student ID";
            // 
            // mark_atten_bt
            // 
            mark_atten_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            mark_atten_bt.Location = new Point(58, 451);
            mark_atten_bt.Name = "mark_atten_bt";
            mark_atten_bt.Size = new Size(450, 72);
            mark_atten_bt.TabIndex = 69;
            mark_atten_bt.Text = "Mark Student Attendance";
            mark_atten_bt.UseVisualStyleBackColor = true;
            mark_atten_bt.Click += mark_atten_bt_Click;
            // 
            // student_atten_grid
            // 
            student_atten_grid.BackgroundColor = SystemColors.Control;
            student_atten_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            student_atten_grid.Location = new Point(58, 101);
            student_atten_grid.MultiSelect = false;
            student_atten_grid.Name = "student_atten_grid";
            student_atten_grid.ReadOnly = true;
            student_atten_grid.RowHeadersWidth = 62;
            student_atten_grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            student_atten_grid.Size = new Size(902, 319);
            student_atten_grid.TabIndex = 68;
            student_atten_grid.CellClick += student_atten_grid_CellClick;
            // 
            // status_combo_bx
            // 
            status_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            status_combo_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            status_combo_bx.FormattingEnabled = true;
            status_combo_bx.Location = new Point(1265, 164);
            status_combo_bx.Name = "status_combo_bx";
            status_combo_bx.Size = new Size(189, 44);
            status_combo_bx.TabIndex = 79;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(1022, 170);
            label2.Name = "label2";
            label2.Size = new Size(196, 32);
            label2.TabIndex = 78;
            label2.Text = "Attendane Status";
            // 
            // Student_id_combo_bx
            // 
            Student_id_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            Student_id_combo_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Student_id_combo_bx.FormattingEnabled = true;
            Student_id_combo_bx.Location = new Point(1265, 95);
            Student_id_combo_bx.Name = "Student_id_combo_bx";
            Student_id_combo_bx.Size = new Size(189, 44);
            Student_id_combo_bx.TabIndex = 81;
            // 
            // atten_rec_combo_bx
            // 
            atten_rec_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            atten_rec_combo_bx.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            atten_rec_combo_bx.FormattingEnabled = true;
            atten_rec_combo_bx.Location = new Point(547, 23);
            atten_rec_combo_bx.Name = "atten_rec_combo_bx";
            atten_rec_combo_bx.Size = new Size(362, 53);
            atten_rec_combo_bx.TabIndex = 83;
            atten_rec_combo_bx.SelectedIndexChanged += atten_rec_combo_bx_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 26);
            label1.Name = "label1";
            label1.Size = new Size(491, 45);
            label1.TabIndex = 82;
            label1.Text = "Select Existing attendance record";
            // 
            // add_new_atten_rec_bt
            // 
            add_new_atten_rec_bt.Font = new Font("Algerian", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            add_new_atten_rec_bt.Location = new Point(1268, 451);
            add_new_atten_rec_bt.Name = "add_new_atten_rec_bt";
            add_new_atten_rec_bt.Size = new Size(143, 49);
            add_new_atten_rec_bt.TabIndex = 84;
            add_new_atten_rec_bt.Text = "Add";
            add_new_atten_rec_bt.UseVisualStyleBackColor = true;
            add_new_atten_rec_bt.Click += add_new_atten_rec_bt_Click;
            // 
            // del_atten_rec_bt
            // 
            del_atten_rec_bt.Dock = DockStyle.Bottom;
            del_atten_rec_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            del_atten_rec_bt.Location = new Point(0, 554);
            del_atten_rec_bt.Name = "del_atten_rec_bt";
            del_atten_rec_bt.Size = new Size(1480, 66);
            del_atten_rec_bt.TabIndex = 85;
            del_atten_rec_bt.Text = "Delete current attendance record";
            del_atten_rec_bt.UseVisualStyleBackColor = true;
            del_atten_rec_bt.Click += del_atten_rec_bt_Click;
            // 
            // remove_atten_bt
            // 
            remove_atten_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            remove_atten_bt.Location = new Point(569, 451);
            remove_atten_bt.Name = "remove_atten_bt";
            remove_atten_bt.Size = new Size(385, 72);
            remove_atten_bt.TabIndex = 86;
            remove_atten_bt.Text = "Remove Student Attendance";
            remove_atten_bt.UseVisualStyleBackColor = true;
            remove_atten_bt.Click += remove_atten_bt_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(1022, 269);
            label3.Name = "label3";
            label3.Size = new Size(389, 38);
            label3.TabIndex = 87;
            label3.Text = "Add new Attendance Record";
            // 
            // Student_Attendance
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            Controls.Add(label3);
            Controls.Add(remove_atten_bt);
            Controls.Add(del_atten_rec_bt);
            Controls.Add(add_new_atten_rec_bt);
            Controls.Add(atten_rec_combo_bx);
            Controls.Add(label1);
            Controls.Add(Student_id_combo_bx);
            Controls.Add(status_combo_bx);
            Controls.Add(label2);
            Controls.Add(date_created);
            Controls.Add(date_labl);
            Controls.Add(stu_id_labl);
            Controls.Add(mark_atten_bt);
            Controls.Add(student_atten_grid);
            Name = "Student_Attendance";
            Size = new Size(1480, 620);
            ((System.ComponentModel.ISupportInitialize)student_atten_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DateTimePicker date_created;
        private Label date_labl;
        private Label stu_id_labl;
        private Button mark_atten_bt;
        private DataGridView student_atten_grid;
        private ComboBox status_combo_bx;
        private Label label2;
        private ComboBox Student_id_combo_bx;
        private ComboBox atten_rec_combo_bx;
        private Label label1;
        private Button add_new_atten_rec_bt;
        private Button del_atten_rec_bt;
        private Button remove_atten_bt;
        private Label label3;
    }
}
