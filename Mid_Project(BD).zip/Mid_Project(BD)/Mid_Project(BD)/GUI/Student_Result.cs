﻿using iTextSharp.text.pdf;
using Microsoft.Data.SqlClient;
using Mid_Project_BD_.Bussiness_Layer;
using System;
using iTextSharp.text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Student_Result : UserControl
    {
        public Student_Result()
        {
            InitializeComponent();
            refresh_combo_bxs();
        }


        private void refresh_combo_bxs()
        {
            // Rubric Level Obtained
            Configuration.refresh_connection();
            SqlCommand cmd_lvl = new SqlCommand("Select * from ProjectB.dbo.RubricLevel;", Configuration.getInstance().getConnection());
            SqlDataAdapter da_lvl = new SqlDataAdapter(cmd_lvl);
            DataTable dt_lvl = new DataTable();
            da_lvl.Fill(dt_lvl);
            rubric_lvl_combo_bx.DisplayMember = "MeasurementLevel";
            rubric_lvl_combo_bx.DataSource = dt_lvl;

            // Assessment Box
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.Assessment;", Configuration.getInstance().getConnection());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            DataColumn display_column = new DataColumn("DisplayColumn", typeof(string));
            dt.Columns.Add(display_column);

            foreach (DataRow row in dt.Rows)
            {
                string concatenatedValue = $"{row[0]}--- {row[1]}";
                row["DisplayColumn"] = concatenatedValue;
            }

            assessment_id_combo_bx.DisplayMember = "DisplayColumn";
            assessment_id_combo_bx.DataSource = dt;
            assessment_id_combo_bx.Refresh();


            // Assessment Component
            Configuration.refresh_connection();
            SqlCommand cmd1 = new SqlCommand("Select * from ProjectB.dbo.AssessmentComponent;", Configuration.getInstance().getConnection());
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            DataColumn display_column1 = new DataColumn("DisplayColumn", typeof(string));
            dt1.Columns.Add(display_column1);

            foreach (DataRow row in dt1.Rows)
            {
                string concatenatedValue = $"{row[0]}--- {row[1]}";
                row["DisplayColumn"] = concatenatedValue;
            }

            assess_compo_combo_bx.DisplayMember = "DisplayColumn";
            assess_compo_combo_bx.DataSource = dt1;
            assess_compo_combo_bx.Refresh();


            // Rubric Combo Box
            Configuration.refresh_connection();
            SqlCommand cmd2 = new SqlCommand("Select * from ProjectB.dbo.Rubric;", Configuration.getInstance().getConnection());
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);

            rubric_id_combo_bx.DisplayMember = "Id";
            rubric_id_combo_bx.DataSource = dt2;
            rubric_id_combo_bx.Refresh();

            // Registration no
            Configuration.refresh_connection();
            SqlCommand cmd3 = new SqlCommand("Select * from ProjectB.dbo.Student;", Configuration.getInstance().getConnection());
            SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
            DataTable dt3 = new DataTable();
            da3.Fill(dt3);
            DataColumn display_column3 = new DataColumn("DisplayColumn", typeof(string));
            dt3.Columns.Add(display_column3);

            foreach (DataRow row in dt3.Rows)
            {
                string concatenatedValue = $"{row[0]}--- {row[1]}";
                row["DisplayColumn"] = concatenatedValue;
            }

            Student_id_combo_bx.DisplayMember = "DisplayColumn";
            Student_id_combo_bx.DataSource = dt3;
            Student_id_combo_bx.Refresh();


            // Rubric Level Obtained

        }

        private void Student_Result_Load(object sender, EventArgs e)
        {

        }

        private void add_result_bt_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand check_command = new SqlCommand("Select * from StudentResult where StudentId = @stu_id and AssessmentComponentId = @ass_compo_id; ", con);
            check_command.Parameters.AddWithValue("stu_id", int.Parse(Student_id_combo_bx.Text.Substring(0, Student_id_combo_bx.Text.IndexOf('-'))));
            check_command.Parameters.AddWithValue("@ass_compo_id", int.Parse(assess_compo_combo_bx.Text.Substring(0, assess_compo_combo_bx.Text.IndexOf('-'))));
            SqlDataAdapter check_adopter = new SqlDataAdapter(check_command);
            DataTable check_table = new DataTable();
            check_adopter.Fill(check_table);

            if (check_table.Rows.Count != 0)
            {
                MessageBox.Show("Can't add a new student result for a student with already existing record.");
                return;
            }


            SqlCommand cmd = new SqlCommand("Insert into ProjectB.dbo.StudentResult (StudentId, AssessmentComponentId, RubricMeasurementId, EvaluationDate) values (@stu_id, @ass_compo_id, @rubric_lvl, @date);", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("@stu_id", int.Parse(Student_id_combo_bx.Text.Substring(0, Student_id_combo_bx.Text.IndexOf('-'))));
            cmd.Parameters.AddWithValue("@ass_compo_id", int.Parse(assess_compo_combo_bx.Text.Substring(0, assess_compo_combo_bx.Text.IndexOf('-'))));
            cmd.Parameters.AddWithValue("@date", date_of_evaluation.Value.Date.ToString("yyyy-MM-dd"));
            SqlCommand cmd1 = new SqlCommand("Select Id from RubricLevel where RubricLevel.RubricId = @rubric_id and RubricLevel.MeasurementLevel = @lvl;", Configuration.getInstance().getConnection());
            cmd1.Parameters.AddWithValue("@rubric_id", rubric_id_combo_bx.Text);
            cmd1.Parameters.AddWithValue("@lvl", rubric_lvl_combo_bx.Text);
            Configuration.refresh_connection();
            object result = cmd1.ExecuteScalar();
            int rubric_lvl_id = Convert.ToInt32(result);
            cmd.Parameters.AddWithValue("@rubric_lvl", rubric_lvl_id);
            Configuration.refresh_connection();
            cmd.ExecuteNonQuery();

            MessageBox.Show("Result Added Successfully");
            refresh_combo_bxs();
        }

        private void view_result_bt_Click(object sender, EventArgs e)
        {
            View_results view_Results = new View_results();
            Pop_Up_Form form = new Pop_Up_Form(view_Results);
            form.Show();
        }

        private void generate_assess_report_Click(object sender, EventArgs e)
        {
            DataTable Result_table = View_results.get_result_table();


            // Create a new document
            Document doc = new Document();
            string outputPath = @"C:\Users\MirZa\OneDrive\Desktop\datatable_to_pdf.pdf";

            // Set up the PDF writer
            PdfWriter writer = PdfWriter.GetInstance(doc, new FileStream(outputPath, FileMode.Create));

            // Open the document for writing
            doc.Open();

            // Create a PDF table with the same number of columns as the DataTable
            PdfPTable pdfTable = new PdfPTable(Result_table.Columns.Count);
            pdfTable.WidthPercentage = 110;
            float[] columnWidths = [45f, 45f, 45f, 60, 60, 45, 42, 42];
            pdfTable.SetWidths(columnWidths);

            // Add column headers
            foreach (DataColumn column in Result_table.Columns)
            {
                pdfTable.AddCell(column.ColumnName);
            }

            // Add data rows
            foreach (DataRow row in Result_table.Rows)
            {
                foreach (var item in row.ItemArray)
                {
                    pdfTable.AddCell(item.ToString());
                }
            }

            // Add the table to the document
            doc.Add(pdfTable);

            // Close the document
            doc.Close();

            MessageBox.Show("Report Generated Successfully.");
        }

        private void generate_clo_report_bt_Click(object sender, EventArgs e)
        {

        }
    }
}
