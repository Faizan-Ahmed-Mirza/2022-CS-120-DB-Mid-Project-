﻿using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Manage_assessments : UserControl
    {
        public Manage_assessments()
        {
            InitializeComponent();
            refresh_assessment_data();
        }


        private void Add_bt_Click(object sender, EventArgs e)
        {
            if (title_txt_bx != null && dateTimePicker1 != null && marks_txt_bx != null && weightage_txt_bx != null)
            {
                if (!int.TryParse(marks_txt_bx.Text, out _) || !int.TryParse(weightage_txt_bx.Text, out _))
                {
                    MessageBox.Show("Marks and Wheightage must be a numeric value.");
                    return;
                }

                var con = Configuration.getInstance().getConnection();
                SqlCommand check_command = new SqlCommand("Select * from ProjectB.dbo.Assessment where Title = @title;", con);
                check_command.Parameters.AddWithValue("@title", title_txt_bx.Text);
                SqlDataAdapter check_adopter = new SqlDataAdapter(check_command);
                DataTable check_table = new DataTable();
                check_adopter.Fill(check_table);

                if (check_table.Rows.Count != 0)
                {
                    MessageBox.Show("Can't add a new Assessment with already existing Title.");
                    return;
                }



                SqlCommand cmd = new SqlCommand("Insert into dbo.Assessment values (@title, @date, @total_marks, @weightage)", con);
                cmd.Parameters.AddWithValue("@title", title_txt_bx.Text);
                cmd.Parameters.AddWithValue("@date", dateTimePicker1.Value.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@total_marks", marks_txt_bx.Text);
                cmd.Parameters.AddWithValue("@weightage", weightage_txt_bx.Text);
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                refresh_assessment_data();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }


        private void Update_bt_Click(object sender, EventArgs e)
        {
            if (title_txt_bx != null && dateTimePicker1 != null && marks_txt_bx != null && weightage_txt_bx != null)
            {
                if (!int.TryParse(marks_txt_bx.Text, out _))
                {
                    MessageBox.Show("Status Must be a number");
                }

                SqlCommand cmd = new SqlCommand("Update ProjectB.dbo.Assessment set Title = @title, DateCreated = @date, TotalMarks = @marks,TotalWeightage = @weightage where Id = @id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@title", title_txt_bx.Text);
                cmd.Parameters.AddWithValue("@date", dateTimePicker1.Value.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@weightage", weightage_txt_bx.Text);
                cmd.Parameters.AddWithValue("@marks", marks_txt_bx.Text);
                cmd.Parameters.AddWithValue("@id", assessment_grid.SelectedRows[0].Cells[0].Value);
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Assessment info updated successfully!");
                refresh_assessment_data();
            }

            else
            {
                MessageBox.Show("Null Values are allowed only for Last_Name and Contact...");
            }
        }


        private void Remove_bt_Click(object sender, EventArgs e)
        {
            if (assessment_grid.SelectedCells == null)
            {
                MessageBox.Show("Please select an assessment first.");
                return;
            }

            SqlCommand cmd = new SqlCommand("Delete from dbo.Assessment where Assessment.Id = @id", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("@id", assessment_grid.SelectedRows[0].Cells["Id"].Value);
            SqlCommand cmd1 = new SqlCommand("Delete from ProjectB.dbo.AssessmentComponent where AssessmentId = @id;", Configuration.getInstance().getConnection());
            cmd1.Parameters.AddWithValue("@id", assessment_grid.SelectedRows[0].Cells["Id"].Value);
            Configuration.refresh_connection();
            cmd1.ExecuteNonQuery();
            Configuration.refresh_connection();
            cmd.ExecuteNonQuery();
            refresh_assessment_data();
        }


        private void assessment_grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (assessment_grid.SelectedRows.Count > 0)
            {
                DataGridViewRow selected_row = assessment_grid.SelectedRows[0];
                title_txt_bx.Text = selected_row.Cells[1].Value.ToString();
                dateTimePicker1.Text = selected_row.Cells[2].Value.ToString();
                marks_txt_bx.Text = selected_row.Cells[3].Value.ToString();
                weightage_txt_bx.Text = selected_row.Cells[4].Value.ToString();
            }
        }


        private void refresh_assessment_data()
        {
            SqlConnection con = Configuration.getInstance().getConnection();
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select* from dbo.Assessment", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            assessment_grid.DataSource = dt;
        }

    }
}
