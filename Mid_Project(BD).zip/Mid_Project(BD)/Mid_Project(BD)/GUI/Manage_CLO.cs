﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Manage_CLO : UserControl
    {
        public Manage_CLO()
        {
            InitializeComponent();
            refresh_clo_grid();
        }

        private void Add_bt_Click(object sender, EventArgs e)
        {
            if (name_txt_bx != null && date_created != null && date_updated != null)
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand check_command = new SqlCommand("Select * from ProjectB.dbo.Clo where Name = @name;", con);
                check_command.Parameters.AddWithValue("@name", name_txt_bx.Text);
                SqlDataAdapter check_adopter = new SqlDataAdapter(check_command);
                DataTable check_table = new DataTable();
                check_adopter.Fill(check_table);

                if (check_table.Rows.Count != 0)
                {
                    MessageBox.Show("Can't add a new CLO with Name already existing .");
                    return;
                }



                SqlCommand cmd = new SqlCommand("Insert into ProjectB.dbo.Clo (Name, DateCreated, DateUpdated) values(@name, @date_created, @date_updated);", con);
                cmd.Parameters.AddWithValue("@name", name_txt_bx.Text);
                cmd.Parameters.AddWithValue("@date_created", date_created.Value.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@date_updated", date_updated.Value.Date.ToString("yyyy-MM-dd"));
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                refresh_clo_grid();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }

        private void Update_bt_Click(object sender, EventArgs e)
        {
            if (name_txt_bx != null && date_created != null && date_updated != null)
            {
                SqlCommand cmd = new SqlCommand("Update ProjectB.dbo.Clo set Name = @name, DateCreated = @date_created, DateUpdated = @date_updated where Id = @id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@name", name_txt_bx.Text);
                cmd.Parameters.AddWithValue("@date_created", date_created.Value.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@date_updated", date_updated.Value.Date.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@id", clo_grid.SelectedRows[0].Cells[0].Value);
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("CLO info updated successfully!");
                refresh_clo_grid();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }

        private void Remove_bt_Click(object sender, EventArgs e)
        {
            if (clo_grid.SelectedCells == null)
            {
                MessageBox.Show("Please select an assessment first.");
                return;
            }

            SqlCommand cmd = new SqlCommand("Delete from dbo.Clo where Clo.Id = @id", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("@id", clo_grid.SelectedRows[0].Cells["Id"].Value);
            SqlCommand cmd1 = new SqlCommand("Delete from ProjectB.dbo.Rubric where CloId = @clo_id;", Configuration.getInstance().getConnection());
            cmd1.Parameters.AddWithValue("@clo_id", clo_grid.SelectedRows[0].Cells["Id"].Value);
            SqlCommand cmd2 = new SqlCommand("Select Id from Rubric where CloId = @clo_id;", Configuration.getInstance().getConnection());
            cmd2.Parameters.AddWithValue("@clo_id", clo_grid.SelectedRows[0].Cells["Id"].Value);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd2);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            Program.delete_assessment_compo_against_rubric_ids(dt);
            Program.delete_rubric_levels_against_rubric_ids(dt);
            Configuration.refresh_connection();
            cmd1.ExecuteNonQuery();
            Configuration.refresh_connection();
            cmd.ExecuteNonQuery();
            refresh_clo_grid();
        }

        private void clo_grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (clo_grid.SelectedRows.Count > 0)
            {
                DataGridViewRow selected_row = clo_grid.SelectedRows[0];
                name_txt_bx.Text = selected_row.Cells[1].Value.ToString();
                date_created.Text = selected_row.Cells[2].Value.ToString();
                date_updated.Text = selected_row.Cells[3].Value.ToString();
            }
        }

        private void refresh_clo_grid()
        {
            SqlConnection con = Configuration.getInstance().getConnection();
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select* from dbo.Clo", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            clo_grid.DataSource = dt;
        }
    }
}
