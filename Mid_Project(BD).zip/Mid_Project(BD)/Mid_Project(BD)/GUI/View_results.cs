﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class View_results : UserControl
    {
        public View_results()
        {
            InitializeComponent();
            student_result_grid.DataSource = get_result_table();

        }

        public static DataTable get_result_table()
        {
            // Helping Structure and variables
            DataTable Result_table = new DataTable();

            // Getting Student IDs
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.StudentResult;", Configuration.getInstance().getConnection());
            SqlDataAdapter stu_ids_da = new SqlDataAdapter(cmd);
            stu_ids_da.Fill(Result_table);

            // Getting Student Names
            Configuration.refresh_connection();
            DataColumn name_column = new DataColumn("Name", typeof(string));
            Result_table.Columns.Add(name_column);
            string name;
            foreach (DataRow sample_row in Result_table.Rows)
            {
                SqlCommand cmd1 = new SqlCommand("Select Student.FirstName from ProjectB.dbo.Student where Student.Id = @id;", Configuration.getInstance().getConnection());
                cmd1.Parameters.AddWithValue("@id", sample_row[0]);
                name = cmd1.ExecuteScalar().ToString();
                sample_row[4] = name;
            }


            // Getting Assessment Id
            Configuration.refresh_connection();
            DataColumn assess_id = new DataColumn("Assessment Id", typeof(int));
            Result_table.Columns.Add(assess_id);
            int assessment_id;
            foreach (DataRow sample_row in Result_table.Rows)
            {
                SqlCommand cmd2 = new SqlCommand("Select AssessmentId from ProjectB.dbo.AssessmentComponent where AssessmentComponent.Id = @id;", Configuration.getInstance().getConnection());
                cmd2.Parameters.AddWithValue("@id", sample_row[1]);
                assessment_id = int.Parse(cmd2.ExecuteScalar().ToString());
                sample_row[5] = assessment_id;
            }


            // Getting Assessment Titile
            Configuration.refresh_connection();
            DataColumn assess_title_clm = new DataColumn("Assessment Title", typeof(string));
            Result_table.Columns.Add(assess_title_clm);
            string assess_title = "";
            foreach (DataRow sample_row in Result_table.Rows)
            {
                SqlCommand cmd2 = new SqlCommand("Select Title from ProjectB.dbo.Assessment where Assessment.Id = @id;", Configuration.getInstance().getConnection());
                cmd2.Parameters.AddWithValue("@id", sample_row[5]);
                assess_title = cmd2.ExecuteScalar().ToString();
                sample_row[6] = assess_title;
            }


            // Getting Assessment Component Name
            Configuration.refresh_connection();
            DataColumn compo_name_clm = new DataColumn("Component Name", typeof(string));
            Result_table.Columns.Add(compo_name_clm);
            string compo_name = "";
            foreach (DataRow sample_row in Result_table.Rows)
            {
                SqlCommand cmd2 = new SqlCommand("Select Name from ProjectB.dbo.AssessmentComponent where Id = @id;", Configuration.getInstance().getConnection());
                cmd2.Parameters.AddWithValue("@id", sample_row[1]);
                compo_name = cmd2.ExecuteScalar().ToString();
                sample_row[7] = compo_name;
            }


            // Getting Assessment Component Marks
            Configuration.refresh_connection();
            DataColumn compo_marks_clm = new DataColumn("Component Marks", typeof(int));
            Result_table.Columns.Add(compo_marks_clm);
            int compo_marks;
            foreach (DataRow sample_row in Result_table.Rows)
            {
                SqlCommand cmd2 = new SqlCommand("Select TotalMarks from ProjectB.dbo.AssessmentComponent where Id = @id;", Configuration.getInstance().getConnection());
                cmd2.Parameters.AddWithValue("@id", sample_row[1]);
                compo_marks = int.Parse(cmd2.ExecuteScalar().ToString());
                sample_row[8] = compo_marks;
            }


            // Getting obtained measurement lvl
            Configuration.refresh_connection();
            DataColumn obtained_lvl_clm = new DataColumn("Obtained Level", typeof(int));
            Result_table.Columns.Add(obtained_lvl_clm);
            int obtained_lvl;
            foreach (DataRow sample_row in Result_table.Rows)
            {
                SqlCommand cmd2 = new SqlCommand("Select MeasurementLevel from ProjectB.dbo.RubricLevel where Id = @id;", Configuration.getInstance().getConnection());
                cmd2.Parameters.AddWithValue("@id", sample_row[2]);
                obtained_lvl = int.Parse(cmd2.ExecuteScalar().ToString());
                sample_row[9] = obtained_lvl;
            }


            // Getting Rubric Id
            Configuration.refresh_connection();
            DataColumn rubric_id_clm = new DataColumn("Rubric Id", typeof(int));
            Result_table.Columns.Add(rubric_id_clm);
            int rubric_id;
            foreach (DataRow sample_row in Result_table.Rows)
            {
                SqlCommand cmd2 = new SqlCommand("Select RubricId from ProjectB.dbo.RubricLevel where Id = @id;", Configuration.getInstance().getConnection());
                cmd2.Parameters.AddWithValue("@id", sample_row[2]);
                rubric_id = int.Parse(cmd2.ExecuteScalar().ToString());
                sample_row[10] = rubric_id;
            }


            // Getting Rubric Details
            Configuration.refresh_connection();
            DataColumn rubric_details_clm = new DataColumn("Rubric", typeof(string));
            Result_table.Columns.Add(rubric_details_clm);
            string rubric_detail;
            foreach (DataRow sample_row in Result_table.Rows)
            {
                SqlCommand cmd2 = new SqlCommand("Select Details from ProjectB.dbo.Rubric where Rubric.Id = @id;", Configuration.getInstance().getConnection());
                cmd2.Parameters.AddWithValue("@id", sample_row[10]);
                rubric_detail = cmd2.ExecuteScalar().ToString();
                sample_row[11] = rubric_detail;
            }


            // Setting Obtained Marks
            Configuration.refresh_connection();
            DataColumn obtained_marks_clm = new DataColumn("Obtained Marks", typeof(float));
            Result_table.Columns.Add(obtained_marks_clm);
            float obtained_marks;
            int max_rubric_lvl;
            foreach (DataRow sample_row in Result_table.Rows)
            {
                SqlCommand cmd2 = new SqlCommand("Select Max(RubricLevel.MeasurementLevel) from RubricLevel where RubricId = @id;", Configuration.getInstance().getConnection());
                cmd2.Parameters.AddWithValue("@id", sample_row[10]);
                max_rubric_lvl = int.Parse(cmd2.ExecuteScalar().ToString());
                obtained_marks = (float.Parse(sample_row[9].ToString()) / max_rubric_lvl) * float.Parse(sample_row[8].ToString());
                sample_row[12] = obtained_marks;
            }


            // Removing un-necessary columns
            Result_table.Columns.Remove("Rubric Id");
            Result_table.Columns.Remove("Assessment Id");
            Result_table.Columns.Remove("AssessmentComponentId");
            Result_table.Columns.Remove("RubricMeasurementId");
            Result_table.Columns.Remove("EvaluationDate");


            // Setting Columns Orders
            Result_table.Columns["StudentId"].SetOrdinal(0);
            Result_table.Columns["Name"].SetOrdinal(1);
            Result_table.Columns["Rubric"].SetOrdinal(2);
            Result_table.Columns["Assessment Title"].SetOrdinal(3);
            Result_table.Columns["Component Name"].SetOrdinal(4);
            Result_table.Columns["Component Marks"].SetOrdinal(5);
            Result_table.Columns["Obtained Level"].SetOrdinal(6);
            Result_table.Columns["Obtained Marks"].SetOrdinal(7);

            // Return Table
            return Result_table;
        }
    }
}
