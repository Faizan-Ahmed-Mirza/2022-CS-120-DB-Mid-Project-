﻿namespace Mid_Project_BD_.GUI
{
    partial class Manage_assessments
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Update_bt = new Button();
            date_labl = new Label();
            weightage_txt_bx = new TextBox();
            weightage_labl = new Label();
            marks_labl = new Label();
            marks_txt_bx = new TextBox();
            title_txt_bx = new TextBox();
            title_labl = new Label();
            Remove_bt = new Button();
            Add_bt = new Button();
            assessment_grid = new DataGridView();
            dateTimePicker1 = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)assessment_grid).BeginInit();
            SuspendLayout();
            // 
            // Update_bt
            // 
            Update_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Update_bt.Location = new Point(611, 499);
            Update_bt.Name = "Update_bt";
            Update_bt.Size = new Size(280, 79);
            Update_bt.TabIndex = 46;
            Update_bt.Text = "Update \r\nAssessment info";
            Update_bt.UseVisualStyleBackColor = true;
            Update_bt.Click += Update_bt_Click;
            // 
            // date_labl
            // 
            date_labl.AutoSize = true;
            date_labl.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_labl.Location = new Point(1149, 326);
            date_labl.Name = "date_labl";
            date_labl.Size = new Size(220, 38);
            date_labl.TabIndex = 43;
            date_labl.Text = "Date of Creation";
            // 
            // weightage_txt_bx
            // 
            weightage_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            weightage_txt_bx.Location = new Point(1267, 251);
            weightage_txt_bx.Name = "weightage_txt_bx";
            weightage_txt_bx.Size = new Size(189, 42);
            weightage_txt_bx.TabIndex = 41;
            // 
            // weightage_labl
            // 
            weightage_labl.AutoSize = true;
            weightage_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            weightage_labl.Location = new Point(1047, 257);
            weightage_labl.Name = "weightage_labl";
            weightage_labl.Size = new Size(187, 32);
            weightage_labl.TabIndex = 40;
            weightage_labl.Text = "Total Weightage";
            // 
            // marks_labl
            // 
            marks_labl.AutoSize = true;
            marks_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            marks_labl.Location = new Point(1047, 191);
            marks_labl.Name = "marks_labl";
            marks_labl.Size = new Size(136, 32);
            marks_labl.TabIndex = 39;
            marks_labl.Text = "Total Marks";
            // 
            // marks_txt_bx
            // 
            marks_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            marks_txt_bx.Location = new Point(1267, 185);
            marks_txt_bx.Name = "marks_txt_bx";
            marks_txt_bx.Size = new Size(189, 42);
            marks_txt_bx.TabIndex = 38;
            // 
            // title_txt_bx
            // 
            title_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            title_txt_bx.Location = new Point(1267, 123);
            title_txt_bx.Name = "title_txt_bx";
            title_txt_bx.Size = new Size(189, 42);
            title_txt_bx.TabIndex = 37;
            // 
            // title_labl
            // 
            title_labl.AutoSize = true;
            title_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            title_labl.Location = new Point(1047, 129);
            title_labl.Name = "title_labl";
            title_labl.Size = new Size(60, 32);
            title_labl.TabIndex = 36;
            title_labl.Text = "Title";
            // 
            // Remove_bt
            // 
            Remove_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Remove_bt.Location = new Point(1077, 499);
            Remove_bt.Name = "Remove_bt";
            Remove_bt.Size = new Size(278, 79);
            Remove_bt.TabIndex = 33;
            Remove_bt.Text = "Remove";
            Remove_bt.UseVisualStyleBackColor = true;
            Remove_bt.Click += Remove_bt_Click;
            // 
            // Add_bt
            // 
            Add_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Add_bt.Location = new Point(121, 499);
            Add_bt.Name = "Add_bt";
            Add_bt.Size = new Size(280, 79);
            Add_bt.TabIndex = 32;
            Add_bt.Text = "Add  Assessment";
            Add_bt.UseVisualStyleBackColor = true;
            Add_bt.Click += Add_bt_Click;
            // 
            // assessment_grid
            // 
            assessment_grid.BackgroundColor = SystemColors.Control;
            assessment_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            assessment_grid.Location = new Point(24, 43);
            assessment_grid.MultiSelect = false;
            assessment_grid.Name = "assessment_grid";
            assessment_grid.ReadOnly = true;
            assessment_grid.RowHeadersWidth = 62;
            assessment_grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            assessment_grid.Size = new Size(1003, 410);
            assessment_grid.TabIndex = 31;
            assessment_grid.CellClick += assessment_grid_CellClick;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateTimePicker1.Location = new Point(1082, 380);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(351, 37);
            dateTimePicker1.TabIndex = 47;
            // 
            // Manage_assessments
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            Controls.Add(dateTimePicker1);
            Controls.Add(Update_bt);
            Controls.Add(date_labl);
            Controls.Add(weightage_txt_bx);
            Controls.Add(weightage_labl);
            Controls.Add(marks_labl);
            Controls.Add(marks_txt_bx);
            Controls.Add(title_txt_bx);
            Controls.Add(title_labl);
            Controls.Add(Remove_bt);
            Controls.Add(Add_bt);
            Controls.Add(assessment_grid);
            Name = "Manage_assessments";
            Size = new Size(1480, 620);
            ((System.ComponentModel.ISupportInitialize)assessment_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Update_bt;
        private Label date_labl;
        private TextBox weightage_txt_bx;
        private Label weightage_labl;
        private Label marks_labl;
        private TextBox marks_txt_bx;
        private TextBox title_txt_bx;
        private Label title_labl;
        private Button Remove_bt;
        private Button Add_bt;
        private DataGridView assessment_grid;
        private DateTimePicker dateTimePicker1;
    }
}
