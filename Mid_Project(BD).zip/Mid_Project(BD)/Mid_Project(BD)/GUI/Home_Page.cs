﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Home_Page : Form
    {
        private UserControl current_section;
        public Home_Page()
        {
            InitializeComponent();
        }

        private void Manage_Students_Click(object sender, EventArgs e)
        {
            Manage_Students student_section = new Manage_Students();
            set_current_section(student_section);

        }

        private void assessment_bt_Click(object sender, EventArgs e)
        {
            Manage_assessments manage_Assessments = new Manage_assessments();
            set_current_section(manage_Assessments);
        }


        private void set_current_section(UserControl section_to_set)
        {
            Home_panel.Controls.Remove(current_section);
            current_section = section_to_set;
            Home_panel.Controls.Add(current_section);
        }

        private void ass_component_bt_Click(object sender, EventArgs e)
        {
            Manage_assessment_components manage_Assessment_Components = new Manage_assessment_components();
            set_current_section(manage_Assessment_Components);
        }

        private void manage_rubric_bt_Click(object sender, EventArgs e)
        {
            Manage_Rubric manage_Rubric = new Manage_Rubric();
            set_current_section(manage_Rubric);
        }

        private void manage_clo_bt_Click(object sender, EventArgs e)
        {
            Manage_CLO manage_CLO = new Manage_CLO();
            set_current_section(manage_CLO);
        }

        private void rubric_lvl_bt_Click(object sender, EventArgs e)
        {
            Manage_Rubric_Level manage_Rubric_levels = new Manage_Rubric_Level();
            set_current_section(manage_Rubric_levels);
        }

        private void mark_atten_bt_Click(object sender, EventArgs e)
        {
            Student_Attendance student_Attendance = new Student_Attendance();
            set_current_section(student_Attendance);
        }

        private void stu_result_bt_Click(object sender, EventArgs e)
        {
            Student_Result student_Result = new Student_Result();
            set_current_section(student_Result);
        }
    }
}
