﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project_BD_.GUI
{
    public partial class Manage_Rubric_Level : UserControl
    {
        public Manage_Rubric_Level()
        {
            InitializeComponent();
            refresh_rubric_id_combo_bx();
            refresh_rubric_lvl_grid();
            measurement_lvl_combo_bx.DataSource = new List<int> { 1, 2, 3, 4 };
        }

        private void Add_bt_Click(object sender, EventArgs e)
        {
            if (rubric_id_combo_bx != null && measurement_lvl_combo_bx != null && Details_txt_bx != null)
            {

                var con = Configuration.getInstance().getConnection();
                SqlCommand check_command = new SqlCommand("Select * from ProjectB.dbo.RubricLevel where RubricId = @rubric_id and MeasurementLevel = @measure_lvl;", con);
                check_command.Parameters.AddWithValue("@rubric_id", int.Parse(rubric_id_combo_bx.Text));
                check_command.Parameters.AddWithValue("@measure_lvl", int.Parse(measurement_lvl_combo_bx.Text));
                SqlDataAdapter check_adopter = new SqlDataAdapter(check_command);
                DataTable check_table = new DataTable();
                check_adopter.Fill(check_table);

                if (check_table.Rows.Count != 0)
                {
                    MessageBox.Show("Can't add a new Record for a Rubric level already existing .");
                    return;
                }



                SqlCommand cmd = new SqlCommand("Insert into ProjectB.dbo.RubricLevel (RubricId, Details, MeasurementLevel) values(@rubric_id, @details, @measurement_lvl);", con);
                cmd.Parameters.AddWithValue("@rubric_id", int.Parse(rubric_id_combo_bx.Text));
                cmd.Parameters.AddWithValue("@details", Details_txt_bx.Text);
                cmd.Parameters.AddWithValue("@measurement_lvl", int.Parse(measurement_lvl_combo_bx.Text));
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                refresh_rubric_lvl_grid();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }

        private void Update_bt_Click(object sender, EventArgs e)
        {
            if (rubric_id_combo_bx != null && measurement_lvl_combo_bx != null && Details_txt_bx != null)
            {
                SqlCommand cmd = new SqlCommand("Update ProjectB.dbo.RubricLevel set RubricId = @rubric_id, Details = @details, MeasurementLevel = @measurement_lvl where RubricLevel.Id = @id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@rubric_id", int.Parse(rubric_id_combo_bx.Text));
                cmd.Parameters.AddWithValue("@details", Details_txt_bx.Text);
                cmd.Parameters.AddWithValue("@measurement_lvl", int.Parse(measurement_lvl_combo_bx.Text));
                cmd.Parameters.AddWithValue("@id", rubric_lvl_grid.SelectedRows[0].Cells["Id"].Value);
                Configuration.refresh_connection();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Rubric Level info updated successfully!");
                refresh_rubric_lvl_grid();
            }

            else
            {
                MessageBox.Show("Null Values are not allowed...");
            }
        }

        private void Remove_bt_Click(object sender, EventArgs e)
        {
            if (rubric_lvl_grid.SelectedCells == null)
            {
                MessageBox.Show("Please select a level first.");
                return;
            }

            SqlCommand cmd = new SqlCommand("Delete from ProjectB.dbo.RubricLevel where Id = @id;", Configuration.getInstance().getConnection());
            cmd.Parameters.AddWithValue("@id", rubric_lvl_grid.SelectedRows[0].Cells["Id"].Value);
            Configuration.refresh_connection();
            cmd.ExecuteNonQuery();
            refresh_rubric_lvl_grid();
        }

        private void rubric_lvl_grid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (rubric_lvl_grid.SelectedRows.Count > 0)
            {
                DataGridViewRow selected_row = rubric_lvl_grid.SelectedRows[0];
                rubric_id_combo_bx.Text = selected_row.Cells[1].Value.ToString();
                Details_txt_bx.Text = selected_row.Cells[2].Value.ToString();
                measurement_lvl_combo_bx.SelectedText = selected_row.Cells[3].Value.ToString();
            }
        }

        private void rubric_id_combo_bx_SelectedIndexChanged(object sender, EventArgs e)
        {
            refresh_rubric_lvl_grid();
        }


        private void refresh_rubric_id_combo_bx()
        {
            Configuration.refresh_connection();
            SqlCommand cmd = new SqlCommand("Select Id from ProjectB.dbo.Rubric;", Configuration.getInstance().getConnection());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            rubric_id_combo_bx.DisplayMember = "Id";
            rubric_id_combo_bx.DataSource = dt;
            rubric_id_combo_bx.Refresh();
        }


        private void refresh_rubric_lvl_grid()
        {
            if (rubric_id_combo_bx.Text != null)
            {
                Configuration.refresh_connection();
                SqlCommand cmd = new SqlCommand("Select * from ProjectB.dbo.RubricLevel where RubricId = @rubric_id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@rubric_id", int.Parse(rubric_id_combo_bx.Text));
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dt.Columns[2].ColumnName = "CLO Id";
                rubric_lvl_grid.DataSource = dt;
                rubric_lvl_grid.Refresh();
            }
        }
    }
}
