﻿namespace Mid_Project_BD_.GUI
{
    partial class Manage_Rubric_Level
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rubric_id_combo_bx = new ComboBox();
            label1 = new Label();
            rubric_lvl_grid = new DataGridView();
            Details_txt_bx = new RichTextBox();
            Update_bt = new Button();
            details_labl = new Label();
            id_labl = new Label();
            Remove_bt = new Button();
            Add_bt = new Button();
            measurement_lvl_combo_bx = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)rubric_lvl_grid).BeginInit();
            SuspendLayout();
            // 
            // rubric_id_combo_bx
            // 
            rubric_id_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            rubric_id_combo_bx.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rubric_id_combo_bx.FormattingEnabled = true;
            rubric_id_combo_bx.Location = new Point(251, 30);
            rubric_id_combo_bx.Name = "rubric_id_combo_bx";
            rubric_id_combo_bx.Size = new Size(356, 53);
            rubric_id_combo_bx.TabIndex = 80;
            rubric_id_combo_bx.SelectedIndexChanged += rubric_id_combo_bx_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(18, 33);
            label1.Name = "label1";
            label1.Size = new Size(204, 45);
            label1.TabIndex = 79;
            label1.Text = "Select Rubric";
            // 
            // rubric_lvl_grid
            // 
            rubric_lvl_grid.BackgroundColor = SystemColors.Control;
            rubric_lvl_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            rubric_lvl_grid.Location = new Point(18, 115);
            rubric_lvl_grid.MultiSelect = false;
            rubric_lvl_grid.Name = "rubric_lvl_grid";
            rubric_lvl_grid.ReadOnly = true;
            rubric_lvl_grid.RowHeadersWidth = 62;
            rubric_lvl_grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            rubric_lvl_grid.Size = new Size(1010, 359);
            rubric_lvl_grid.TabIndex = 78;
            rubric_lvl_grid.CellClick += rubric_lvl_grid_CellClick;
            // 
            // Details_txt_bx
            // 
            Details_txt_bx.Location = new Point(1053, 251);
            Details_txt_bx.Name = "Details_txt_bx";
            Details_txt_bx.Size = new Size(409, 191);
            Details_txt_bx.TabIndex = 77;
            Details_txt_bx.Text = "";
            // 
            // Update_bt
            // 
            Update_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Update_bt.Location = new Point(615, 512);
            Update_bt.Name = "Update_bt";
            Update_bt.Size = new Size(280, 79);
            Update_bt.TabIndex = 76;
            Update_bt.Text = "Update Rubric Level info";
            Update_bt.UseVisualStyleBackColor = true;
            Update_bt.Click += Update_bt_Click;
            // 
            // details_labl
            // 
            details_labl.AutoSize = true;
            details_labl.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            details_labl.Location = new Point(1081, 194);
            details_labl.Name = "details_labl";
            details_labl.Size = new Size(123, 45);
            details_labl.TabIndex = 75;
            details_labl.Text = "Details:";
            // 
            // id_labl
            // 
            id_labl.AutoSize = true;
            id_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            id_labl.Location = new Point(1053, 138);
            id_labl.Name = "id_labl";
            id_labl.Size = new Size(224, 32);
            id_labl.TabIndex = 73;
            id_labl.Text = "Measurement Level";
            // 
            // Remove_bt
            // 
            Remove_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Remove_bt.Location = new Point(1081, 512);
            Remove_bt.Name = "Remove_bt";
            Remove_bt.Size = new Size(278, 79);
            Remove_bt.TabIndex = 72;
            Remove_bt.Text = "Remove";
            Remove_bt.UseVisualStyleBackColor = true;
            Remove_bt.Click += Remove_bt_Click;
            // 
            // Add_bt
            // 
            Add_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Add_bt.Location = new Point(125, 512);
            Add_bt.Name = "Add_bt";
            Add_bt.Size = new Size(280, 79);
            Add_bt.TabIndex = 71;
            Add_bt.Text = "Add Rubric Level";
            Add_bt.UseVisualStyleBackColor = true;
            Add_bt.Click += Add_bt_Click;
            // 
            // measurement_lvl_combo_bx
            // 
            measurement_lvl_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            measurement_lvl_combo_bx.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            measurement_lvl_combo_bx.FormattingEnabled = true;
            measurement_lvl_combo_bx.Location = new Point(1309, 135);
            measurement_lvl_combo_bx.Name = "measurement_lvl_combo_bx";
            measurement_lvl_combo_bx.Size = new Size(138, 40);
            measurement_lvl_combo_bx.TabIndex = 81;
            // 
            // Manage_Rubric_Level
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            Controls.Add(measurement_lvl_combo_bx);
            Controls.Add(rubric_id_combo_bx);
            Controls.Add(label1);
            Controls.Add(rubric_lvl_grid);
            Controls.Add(Details_txt_bx);
            Controls.Add(Update_bt);
            Controls.Add(details_labl);
            Controls.Add(id_labl);
            Controls.Add(Remove_bt);
            Controls.Add(Add_bt);
            Name = "Manage_Rubric_Level";
            Size = new Size(1480, 620);
            ((System.ComponentModel.ISupportInitialize)rubric_lvl_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox rubric_id_combo_bx;
        private Label label1;
        private DataGridView rubric_lvl_grid;
        private RichTextBox Details_txt_bx;
        private Button Update_bt;
        private Label details_labl;
        private Label id_labl;
        private Button Remove_bt;
        private Button Add_bt;
        private ComboBox measurement_lvl_combo_bx;
    }
}
