﻿namespace Mid_Project_BD_.GUI
{
    partial class Manage_assessment_components
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            date_created = new DateTimePicker();
            Update_bt = new Button();
            date_labl = new Label();
            marks_labl = new Label();
            marks_txt_bx = new TextBox();
            name_txt_bx = new TextBox();
            title_labl = new Label();
            Remove_bt = new Button();
            Add_bt = new Button();
            ass_compo_grid = new DataGridView();
            label1 = new Label();
            assessment_combo_bx = new ComboBox();
            label2 = new Label();
            date_updated = new DateTimePicker();
            label3 = new Label();
            rubric_id_combo_bx = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)ass_compo_grid).BeginInit();
            SuspendLayout();
            // 
            // date_created
            // 
            date_created.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_created.Location = new Point(1087, 416);
            date_created.Name = "date_created";
            date_created.Size = new Size(351, 37);
            date_created.TabIndex = 59;
            // 
            // Update_bt
            // 
            Update_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Update_bt.Location = new Point(617, 513);
            Update_bt.Name = "Update_bt";
            Update_bt.Size = new Size(280, 79);
            Update_bt.TabIndex = 58;
            Update_bt.Text = "Update Component info";
            Update_bt.UseVisualStyleBackColor = true;
            Update_bt.Click += Update_bt_Click;
            // 
            // date_labl
            // 
            date_labl.AutoSize = true;
            date_labl.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_labl.Location = new Point(1154, 362);
            date_labl.Name = "date_labl";
            date_labl.Size = new Size(220, 38);
            date_labl.TabIndex = 57;
            date_labl.Text = "Date of Creation";
            // 
            // marks_labl
            // 
            marks_labl.AutoSize = true;
            marks_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            marks_labl.Location = new Point(1055, 186);
            marks_labl.Name = "marks_labl";
            marks_labl.Size = new Size(136, 32);
            marks_labl.TabIndex = 54;
            marks_labl.Text = "Total Marks";
            // 
            // marks_txt_bx
            // 
            marks_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            marks_txt_bx.Location = new Point(1275, 180);
            marks_txt_bx.Name = "marks_txt_bx";
            marks_txt_bx.Size = new Size(189, 42);
            marks_txt_bx.TabIndex = 53;
            // 
            // name_txt_bx
            // 
            name_txt_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            name_txt_bx.Location = new Point(1275, 118);
            name_txt_bx.Name = "name_txt_bx";
            name_txt_bx.Size = new Size(189, 42);
            name_txt_bx.TabIndex = 52;
            // 
            // title_labl
            // 
            title_labl.AutoSize = true;
            title_labl.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            title_labl.Location = new Point(1055, 124);
            title_labl.Name = "title_labl";
            title_labl.Size = new Size(78, 32);
            title_labl.TabIndex = 51;
            title_labl.Text = "Name";
            // 
            // Remove_bt
            // 
            Remove_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Remove_bt.Location = new Point(1083, 513);
            Remove_bt.Name = "Remove_bt";
            Remove_bt.Size = new Size(278, 79);
            Remove_bt.TabIndex = 50;
            Remove_bt.Text = "Remove";
            Remove_bt.UseVisualStyleBackColor = true;
            Remove_bt.Click += Remove_bt_Click;
            // 
            // Add_bt
            // 
            Add_bt.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Add_bt.Location = new Point(127, 513);
            Add_bt.Name = "Add_bt";
            Add_bt.Size = new Size(280, 79);
            Add_bt.TabIndex = 49;
            Add_bt.Text = "Add Component";
            Add_bt.UseVisualStyleBackColor = true;
            Add_bt.Click += Add_bt_Click;
            // 
            // ass_compo_grid
            // 
            ass_compo_grid.BackgroundColor = SystemColors.Control;
            ass_compo_grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ass_compo_grid.Location = new Point(23, 108);
            ass_compo_grid.MultiSelect = false;
            ass_compo_grid.Name = "ass_compo_grid";
            ass_compo_grid.ReadOnly = true;
            ass_compo_grid.RowHeadersWidth = 62;
            ass_compo_grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ass_compo_grid.Size = new Size(1010, 359);
            ass_compo_grid.TabIndex = 48;
            ass_compo_grid.CellClick += ass_compo_grid_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(43, 28);
            label1.Name = "label1";
            label1.Size = new Size(282, 45);
            label1.TabIndex = 60;
            label1.Text = "Select Assessment";
            // 
            // assessment_combo_bx
            // 
            assessment_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            assessment_combo_bx.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            assessment_combo_bx.FormattingEnabled = true;
            assessment_combo_bx.Location = new Point(374, 25);
            assessment_combo_bx.Name = "assessment_combo_bx";
            assessment_combo_bx.Size = new Size(362, 53);
            assessment_combo_bx.TabIndex = 61;
            assessment_combo_bx.SelectedIndexChanged += assessment_combo_bx_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(1055, 245);
            label2.Name = "label2";
            label2.Size = new Size(111, 32);
            label2.TabIndex = 62;
            label2.Text = "Rubric ID";
            // 
            // date_updated
            // 
            date_updated.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            date_updated.Location = new Point(1275, 309);
            date_updated.Name = "date_updated";
            date_updated.Size = new Size(189, 39);
            date_updated.TabIndex = 65;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(1055, 314);
            label3.Name = "label3";
            label3.Size = new Size(162, 32);
            label3.TabIndex = 64;
            label3.Text = "Date Updated";
            // 
            // rubric_id_combo_bx
            // 
            rubric_id_combo_bx.DropDownStyle = ComboBoxStyle.DropDownList;
            rubric_id_combo_bx.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            rubric_id_combo_bx.FormattingEnabled = true;
            rubric_id_combo_bx.Location = new Point(1275, 239);
            rubric_id_combo_bx.Name = "rubric_id_combo_bx";
            rubric_id_combo_bx.Size = new Size(189, 44);
            rubric_id_combo_bx.TabIndex = 66;
            // 
            // Manage_assessment_components
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            Controls.Add(rubric_id_combo_bx);
            Controls.Add(date_updated);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(assessment_combo_bx);
            Controls.Add(label1);
            Controls.Add(date_created);
            Controls.Add(Update_bt);
            Controls.Add(date_labl);
            Controls.Add(marks_labl);
            Controls.Add(marks_txt_bx);
            Controls.Add(name_txt_bx);
            Controls.Add(title_labl);
            Controls.Add(Remove_bt);
            Controls.Add(Add_bt);
            Controls.Add(ass_compo_grid);
            Name = "Manage_assessment_components";
            Size = new Size(1480, 620);
            ((System.ComponentModel.ISupportInitialize)ass_compo_grid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker date_created;
        private Button Update_bt;
        private Label date_labl;
        private Label marks_labl;
        private TextBox marks_txt_bx;
        private TextBox name_txt_bx;
        private Label title_labl;
        private Button Remove_bt;
        private Button Add_bt;
        private DataGridView ass_compo_grid;
        private Label label1;
        private ComboBox assessment_combo_bx;
        private Label label2;
        private DateTimePicker date_updated;
        private Label label3;
        private ComboBox rubric_id_combo_bx;
    }
}
