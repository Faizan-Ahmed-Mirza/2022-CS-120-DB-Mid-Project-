﻿namespace Mid_Project_BD_.GUI
{
    partial class Home_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Manage_Students = new Button();
            Home_panel = new Panel();
            assessment_bt = new Button();
            ass_component_bt = new Button();
            manage_rubric_bt = new Button();
            manage_clo_bt = new Button();
            rubric_lvl_bt = new Button();
            mark_atten_bt = new Button();
            stu_result_bt = new Button();
            SuspendLayout();
            // 
            // Manage_Students
            // 
            Manage_Students.Location = new Point(27, 36);
            Manage_Students.Name = "Manage_Students";
            Manage_Students.Size = new Size(187, 72);
            Manage_Students.TabIndex = 0;
            Manage_Students.Text = "Manage Students";
            Manage_Students.UseVisualStyleBackColor = true;
            Manage_Students.Click += Manage_Students_Click;
            // 
            // Home_panel
            // 
            Home_panel.Location = new Point(261, 103);
            Home_panel.Name = "Home_panel";
            Home_panel.Size = new Size(1480, 620);
            Home_panel.TabIndex = 4;
            // 
            // assessment_bt
            // 
            assessment_bt.Location = new Point(27, 135);
            assessment_bt.Name = "assessment_bt";
            assessment_bt.Size = new Size(187, 69);
            assessment_bt.TabIndex = 5;
            assessment_bt.Text = "Manage Assessments";
            assessment_bt.UseVisualStyleBackColor = true;
            assessment_bt.Click += assessment_bt_Click;
            // 
            // ass_component_bt
            // 
            ass_component_bt.Location = new Point(27, 236);
            ass_component_bt.Name = "ass_component_bt";
            ass_component_bt.Size = new Size(187, 74);
            ass_component_bt.TabIndex = 6;
            ass_component_bt.Text = "Manage Assessment Components";
            ass_component_bt.UseVisualStyleBackColor = true;
            ass_component_bt.Click += ass_component_bt_Click;
            // 
            // manage_rubric_bt
            // 
            manage_rubric_bt.Location = new Point(27, 337);
            manage_rubric_bt.Name = "manage_rubric_bt";
            manage_rubric_bt.Size = new Size(187, 74);
            manage_rubric_bt.TabIndex = 7;
            manage_rubric_bt.Text = "Manage Rubrics";
            manage_rubric_bt.UseVisualStyleBackColor = true;
            manage_rubric_bt.Click += manage_rubric_bt_Click;
            // 
            // manage_clo_bt
            // 
            manage_clo_bt.Location = new Point(27, 435);
            manage_clo_bt.Name = "manage_clo_bt";
            manage_clo_bt.Size = new Size(187, 74);
            manage_clo_bt.TabIndex = 8;
            manage_clo_bt.Text = "Manage CLOs";
            manage_clo_bt.UseVisualStyleBackColor = true;
            manage_clo_bt.Click += manage_clo_bt_Click;
            // 
            // rubric_lvl_bt
            // 
            rubric_lvl_bt.Location = new Point(27, 530);
            rubric_lvl_bt.Name = "rubric_lvl_bt";
            rubric_lvl_bt.Size = new Size(187, 74);
            rubric_lvl_bt.TabIndex = 9;
            rubric_lvl_bt.Text = "Manage Rubric Levels";
            rubric_lvl_bt.UseVisualStyleBackColor = true;
            rubric_lvl_bt.Click += rubric_lvl_bt_Click;
            // 
            // mark_atten_bt
            // 
            mark_atten_bt.Location = new Point(27, 624);
            mark_atten_bt.Name = "mark_atten_bt";
            mark_atten_bt.Size = new Size(187, 74);
            mark_atten_bt.TabIndex = 10;
            mark_atten_bt.Text = "Mark Student Attendance";
            mark_atten_bt.UseVisualStyleBackColor = true;
            mark_atten_bt.Click += mark_atten_bt_Click;
            // 
            // stu_result_bt
            // 
            stu_result_bt.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            stu_result_bt.Location = new Point(27, 726);
            stu_result_bt.Name = "stu_result_bt";
            stu_result_bt.Size = new Size(187, 74);
            stu_result_bt.TabIndex = 11;
            stu_result_bt.Text = "Add Student Result";
            stu_result_bt.UseVisualStyleBackColor = true;
            stu_result_bt.Click += stu_result_bt_Click;
            // 
            // Home_Page
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            ClientSize = new Size(1777, 848);
            Controls.Add(stu_result_bt);
            Controls.Add(mark_atten_bt);
            Controls.Add(rubric_lvl_bt);
            Controls.Add(manage_clo_bt);
            Controls.Add(manage_rubric_bt);
            Controls.Add(ass_component_bt);
            Controls.Add(assessment_bt);
            Controls.Add(Home_panel);
            Controls.Add(Manage_Students);
            Name = "Home_Page";
            Text = "Home_Page";
            ResumeLayout(false);
        }

        #endregion

        private Button Manage_Students;
        private Panel Home_panel;
        private Button assessment_bt;
        private Button ass_component_bt;
        private Button manage_rubric_bt;
        private Button manage_clo_bt;
        private Button rubric_lvl_bt;
        private Button mark_atten_bt;
        private Button stu_result_bt;
    }
}