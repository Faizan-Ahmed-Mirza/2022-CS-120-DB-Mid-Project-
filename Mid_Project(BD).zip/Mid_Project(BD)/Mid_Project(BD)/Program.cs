using Microsoft.Data.SqlClient;
using Mid_Project_BD_.GUI;
using System.Data;
namespace Mid_Project_BD_
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Home_Page());
        }

        public static void delete_rubrics_against_clo(DataTable rubric_ids_table, int clo_id)
        {
            //foreach (DataRow sample_row in rubric_ids_table.Rows)
            //{
                SqlCommand cmd1 = new SqlCommand("Delete from ProjectB.dbo.Rubric where CloId = @clo_id;", Configuration.getInstance().getConnection());
                cmd1.Parameters.AddWithValue("@clo_id", clo_id);
                Configuration.refresh_connection();
            //}
        }


        public static void delete_rubric_levels_against_rubric_ids(DataTable rubric_ids_table)
        {
            foreach (DataRow sample_row in rubric_ids_table.Rows)
            {
                Configuration.refresh_connection();
                SqlCommand cmd = new SqlCommand("Delete from RubricLevel where RubricId = @id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@id", int.Parse(sample_row[0].ToString()));
                cmd.ExecuteNonQuery();
            }
        }


        public static void delete_assessment_compo_against_rubric_ids(DataTable rubric_ids_table)
        {
            foreach (DataRow sample_row in rubric_ids_table.Rows)
            {
                Configuration.refresh_connection();
                SqlCommand cmd = new SqlCommand("Delete from AssessmentComponent where RubricId = @id;", Configuration.getInstance().getConnection());
                cmd.Parameters.AddWithValue("@id", int.Parse(sample_row[0].ToString()));
                cmd.ExecuteNonQuery();
            }
        }
    }
}