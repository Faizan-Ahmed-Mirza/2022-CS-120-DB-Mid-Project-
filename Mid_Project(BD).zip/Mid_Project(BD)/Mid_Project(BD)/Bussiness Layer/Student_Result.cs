﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_Project_BD_.Bussiness_Layer
{
    internal class Student_Result
    {
        int Student_ID;
        int Assessment_componenet_ID;
        int Rubric_measurement_ID;
        string Evaluation_Date;
    }
}
