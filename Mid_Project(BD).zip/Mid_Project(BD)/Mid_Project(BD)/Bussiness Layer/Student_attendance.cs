﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_Project_BD_
{
    internal class Student_attendance
    {
        int Attendace_ID;
        int Student_ID;
        int Attendance_status;
    }
}
