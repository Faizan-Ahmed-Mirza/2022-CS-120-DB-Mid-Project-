﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_Project_BD_
{
    internal class Assessment
    {
        int ID;
        string Title;
        string Date_created;
        int Total_marks;
        int Total_weightage;

        public Assessment() 
        {

        }

        public Assessment(int iD, string title, string date_created, int total_marks, int total_weightage)
        {
            ID = iD;
            Title = title;
            Date_created = date_created;
            Total_marks = total_marks;
            Total_weightage = total_weightage;
        }
    }
}
