﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_Project_BD_
{
    internal class Students
    {
        int ID;
        int status;
        string First_Name;
        string Last_Name;
        string Contact;
        string Email;
        string Registration_no;

        public Students()
        {

        }

        public Students(int iD, int status, string first_Name, string last_Name, string contact, string email, string registration_no)
        {
            ID = iD;
            this.status = status;
            First_Name = first_Name;
            Last_Name = last_Name;
            Contact = contact;
            Email = email;
            Registration_no = registration_no;
        }
    }
}
