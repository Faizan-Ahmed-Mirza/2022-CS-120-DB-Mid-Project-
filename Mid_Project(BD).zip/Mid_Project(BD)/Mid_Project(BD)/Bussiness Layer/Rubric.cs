﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mid_Project_BD_.Bussiness_Layer
{
    internal class Rubric
    {
        int ID;
        int CLO_ID;
        string Details;
    }
}
